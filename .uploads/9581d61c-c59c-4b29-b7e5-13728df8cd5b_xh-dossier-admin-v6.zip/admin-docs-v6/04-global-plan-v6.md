# 整体方案 v6（草案，未冻结）

> 状态：**G0 待批准 / G2 未冻结**。这份文件只给用户、总控、工程部看，**不得发给盲测 Agent**。
> 基线：`Dragon-01-you/xh-dossier` · 远程 `97c192b38961f498555078a1ce1613788c77041e` · 本地 `1fa699ea0b3a215b3dfd36e45f22d5b4f2afd08d`（落后 1 个 commit）
> 日期：2026-11-22

---

## 0. 先说结论

这版方案的核心不是“再写一份计划”，而是把三件事分开：

1. **体验**：6 个 Workstream Owner 在不知道已知 issue 的情况下，各自从零跑完整流程，暴露普通用户真实卡点。
2. **标准**：每一步先有 Must / PASS / 证据级别；没有证据不写 PASS。
3. **实施**：体验报告汇总成 `global-plan`，用户批准后才派实现 Agent；每个 issue 一分支一 PR，独立审查，统一合并。

当前真正卡住发布的不是“代码不够多”，而是 **S4 浏览器导出没有真实落盘证据**：

- 云端干净 Chromium 已跑通“ScriptCat + AfterChat + mock DeepSeek API → `.md` 落盘 → `01` 导入 2 条”，证据级别 L1–L2；
- 真实 DeepSeek 登录态导出未跑通，本地 Edge 环境当前离线；
- 已知 #7 的根因是 Edge `prompt_for_download=True` 弹出 Windows Save As 原生对话框，Agent/扩展点不了；这不是脚本循环。
- 所以：**不能用 mock 结果宣称生产 PASS**；S4 必须单独列 P0，直到真实文件落盘或被用户确认为 `blocked-by-human`。

---

## 1. 目标与非目标

### 目标

- 普通用户只跟本地 AI Agent 对话，完成安装 → 访谈 → 导出 → 清洗 → 校验 → 拿到可用档案。
- 交付 release zip / 安装入口、受控工具契约、6 文件 Kit。
- 每一步有可验收标准、证据、失败画廊。
- Windows 11 + Ubuntu 24.04 双平台可装、可回滚。

### 非目标

- 不做 GUI；
- 不绑定 Dify；
- 不把 raw 上传云端；
- 不在 `D:\芯火剪辑系统` 做任何 git/推送/实验；
- 不在 R0 支持所有平台/所有聊天工具；先 DeepSeek + 本地 Agent 路径。

---

## 2. 当前实测矩阵（截至 2026-11-22）

| 环境 | 已跑什么 | 结果 | 证据级别 | 能不能算 PASS |
|---|---|---|---|---|
| 云端 Linux + 仓库 clone | `pytest -q` | 33 passed | L1 | 只能算单测绿 |
| 云端 Linux + 机械层 | wizard declined / dry-run / 403；validate templates / strict；mock 导出 → 01 → 02 | declined exit 1；dry-run 0；403 原始 traceback；VALIDATE_OK；strict FAIL exit 1；INDEX_OK 2 条；FOUR_WAY_OK | L1–L2 | 机械层 smoke，不是生产 |
| 云端干净 Chromium + Playwright | Chrome Web Store / Edge Addons / GitHub release 下载；ScriptCat 1.5.2；AfterChat 1.25.0；mock DeepSeek | 商店不可达/按钮 disabled；GitHub release 可下；扩展+脚本装成功；重载后按钮出现；导出 374 bytes `.md`；01 导入 2 条 | L1–L2 | 浏览器链路 smoke，不是真实平台 |
| 云端真实 DeepSeek | `/share/...`、`/a/chat/s/...`、登录页 | 分享页无按钮；会话页跳登录；无登录态 | L1 | blocked-by-human |
| 本地 Windows + Edge | 真实登录态导出 | 未跑；本地环境离线；`kmenureg.exe 0xc0000142` 后掉线 | 无 | BLOCKED |
| 本地 AI Agent 对话 | 用户零终端 | 未跑 | 无 | BLOCKED |
| 盲测 | 普通用户视角 | 未跑 | 无 | BLOCKED |

### 结论

- 机械层可以继续并行；
- S4 真实导出是 P0，必须等本地环境回来或用户明确接受 `blocked-by-human`；
- S8 盲测必须在 release 候选出来后跑；
- 现在不能发“生产级 PASS”，只能发“机械层 + 干净浏览器 smoke 已通”。

---

## 3. 问题表（现有 + 本轮新发现）

> 这张表只给总控/工程部。体验 Agent 不看。

### 3.1 GitHub open issues

| ID | 标题 | 优先级 | Workstream | 现状 | 验收 |
|---|---|---|---|---|---|
| #1 | 访谈只产出骨架，L3/L4 信息 A/B/C 问题挖不到 | P0 | WS2 | open | 6 轮每轮至少 1 个 dated+代价；>=6 dated；>=3 L4 |
| #2 | Validator 禁词可绕过，strict 与 `[待确认]` 冲突 | P1 | WS2 | open | strict 对 `[待确认]` INFO 不 fail；禁词/ASCII 全抓 |
| #3 | 访谈 prompt 语言不跟随，Q1/Q3 捆绑 | P1 | WS2 | open | 语言跟随；单选项单一诉求；末位自定义 |
| #4 | 导出指南停在扩展，没提 AfterChat 用户脚本 | P1 | WS3 | open | 手册出现 AfterChat + 安装页 + 重载 |
| #5 | 检索只覆盖 2/4 信号，无图检索/时间检索 | P2 | WS4 | open | 四路有分节；缺的明确 known-limit |
| #6 | 二层回填只查 told，需反向挖 untold | P1 | WS4 | open | 二层三输入 + EXPERIMENTAL + 签字 + needs_llm |
| #7 | 真实导出按钮在、点了没文件；331→56 回退 | P0 | WS3 | open，根因已定位 | 单条/全部各自落盘；Save As = blocked-by-human |
| #9 | E2E problem map 10 checkpoints | P0 | WS3/WS6 | open | 10 CP 逐项有结论 |
| #10 | 事件时间 vs 提及时间，回忆事件被存成“今天发生” | P0 | WS2/WS4 | open | event_date/date_kind 分离；假日期拒绝 |
| #13 | 坏路径 dump traceback；空 raw 静默空库 | P1 | WS1/WS3/WS4 | open | 专属 marker + 非零；空 raw 不静默 |
| #15 | `[待确认]` 不可追溯，有一条编造 | P0 | WS2 | open | 形状可校验；无出处/原文 FAIL |

### 3.2 本轮云端新发现

| ID | 现象 | 优先级 | Workstream | 证据 | 建议 |
|---|---|---|---|---|---|
| C1 | Chrome Web Store 不可达；Edge Addons 在 Chromium 里 `获取` disabled | P1 | WS3 | `extensions-page.png`、商店日志 | 记录环境限制；官方 GitHub release 作为 fallback；不冒充商店通过 |
| C2 | 安装 AfterChat 后不重载扩展，按钮不注入；只 Ctrl+F5 不够 | P0 | WS3 | `mock-deepseek-button.png` vs `mock-after-reload.png` | 文档加“重载扩展一次”；安装向导加检查 |
| C3 | DeepSeek `/share/...` 分享页不注入按钮；adapter 只认 `/a/chat/s/<id>` | P1 | WS3 | `share-after-reload.log` | R0 写 known-limit；后续 issue 支持 share |
| C4 | 导出 metadata `Model: deepseek-deepseek-v4` 重复前缀 | P1 | WS3 | `Mock Conversation.md` | 修 adapter 或本地包装；加 fixture |
| C5 | `00_export_wizard --download-release` 403 输出原始 traceback | P1 | WS1 | `wizard-download-release.log` | `RELEASE_FETCH_FAILED` + exit 2 |
| C6 | 2 条 mock 记录也输出 `FOUR_WAY_OK`，容易被当生产 PASS | P1 | WS4 | `pipeline-fourway.log` | 加“样本量不足”警告；生产 PASS 需 >=100 条真实 |
| C7 | 浏览器证据只有 mock，没有真实登录态落盘 | P0 | WS3/WS6 | 证据目录 | 本地 Edge 真实导出；否则 BLOCKED |
| C8 | 本地 Edge 掉线，真实导出/盲测无法跑 | P0 阻塞 | WS3/WS6 | baseline | 等用户本地重新上线；不假装 |
| C9 | 批量导出 Save As 原生弹窗无法点 | P0 | WS3 | #7 评论 | 归入 #7；文档 + `blocked-by-human` 分类 |
| C10 | 官方 GitHub release 可下，但“商店路径”未验证 | P1 | WS3 | release zip hash | 记录两条路径，不合并结论 |

### 3.3 已关闭但需要回归的

#8 / #11 / #17 / #19 / #21 / #23 / #28 已 CLOSED。实施阶段每个 PR 必须确认这些修复没有被回归；发布门禁核对“CLOSED 的修复是否进待发布分支”。

---

## 4. 6 个 Workstream

| WS | 名称 | 主范围 | 主要 issue | 关键产出 |
|---|---|---|---|---|
| WS1 | 安装 / doctor / Agent 契约 | release zip、doctor、wizard、依赖、错误文案、Agent 入口 | #13（错误路径）、C5 | 干净安装、doctor、wizard、契约 |
| WS2 | 访谈 / Kit / 校验 | 6 轮、6 文件、validate、`[待确认]`、PII/ASCII | #1 #2 #3 #10 #15 | 访谈记录、Kit、validate、fixtures |
| WS3 | 浏览器导出 / 导入清洗 | 扩展、AfterChat、单条/全部、下载、01、真实格式 | #4 #7 #9 C1–C4 C7–C10 | 扩展清单、落盘文件、DB、fixtures |
| WS4 | 四路匹配 / 二层回填 | 02 四路、缺/空 DB、05 回填、needs_llm | #5 #6 #10 #13 C6 | 报告、候选、签字状态、fixtures |
| WS5 | CI / 安全 / 发布 | CI 矩阵、secret/PII、隔离、release、校验和、回滚 | #13（门禁）、H2/H4 | CI、扫描报告、release、rollback |
| WS6 | 文档 / 示例 / 盲测 | 手册、known-limits、示例、盲测 | #4 #9 C3 C7 | 手册、盲测报告、文档 issue |

### 边界

- WS3 拥有“浏览器怎么点、文件怎么落、Save As 怎么处理”；WS1 只拥有“CLI 怎么包装、错误怎么打”。
- WS2 拥有 `[待确认]` 规则和 validator 的单一事实源；WS5 只加 secret scan，不重复实现 PII 规则。
- WS1 拥有安装章节；WS6 拥有其余文档；同一段不两人写。
- WS4 消费 WS3 的 `records` schema；schema 在 `interface-contract.md` 冻结，改 schema 走 CONFLICT。

---

## 5. 工具契约（建议冻结）

### 5.1 CLI

| 命令 | 作用 | 成功 | 失败 |
|---|---|---|---|
| `00_doctor.py` | 环境自检 | `DOCTOR_OK` exit 0 | `DOCTOR_FAIL` exit 2 |
| `00_export_wizard.py` | 导出向导 | consented exit 0 | `WIZARD_DECLINED` 非零；`RELEASE_FETCH_FAILED` exit 2 |
| `01_clean_and_index.py` | 清洗索引 | `INDEX_OK` exit 0 | `RAW_DIR_NOT_FOUND` / `INDEX_EMPTY` / `DB_NOT_FOUND` 非零 |
| `02_four_way_match.py` | 四路匹配 | `FOUR_WAY_OK` exit 0 | `FOUR_WAY_DB_NOT_FOUND` / `FOUR_WAY_EMPTY` 非零 |
| `03_validate_kit.py` | Kit 校验 | `VALIDATE_OK` exit 0 | `VALIDATE_FAIL` exit 1 |
| `05_deep_backfill.py` | 二层回填 | `BACKFILL_OK` exit 0 | `BACKFILL_EXPERIMENTAL` 非零？需定 |
| `06_package_release.py` | 打包发布 | `RELEASE_OK` exit 0 | `RELEASE_FAIL` 非零 |

### 5.2 退出码语义

| 码 | 含义 |
|---|---|
| 0 | 成功 |
| 1 | 校验失败（输入不合法） |
| 2 | 输入/环境错误（缺文件、缺依赖、网络） |
| 3 | 用户拒绝/门禁未通过 |
| 4 | `blocked-by-human`（登录/验证码/系统弹窗） |
| 5 | 高风险，待强审 |

### 5.3 文件布局

```
work/
  raw/                 # 用户本机，不进仓库
  kit/                 # 6 文件
  index.db             # 不进仓库
  reports/
    four_way_match.md
    backfill_candidates.md
  evidence/            # 脱敏后可进仓库
```

### 5.4 Agent 工具入参/出参（概念）

| 工具 | 入参 | 出参 |
|---|---|---|
| `doctor` | 无 | `{ok, checks[], errors[]}` |
| `interview.start` | `{language, profile?}` | `{session_id, question}` |
| `interview.answer` | `{session_id, answer}` | `{next_question, round, done}` |
| `interview.finish` | `{session_id}` | `{kit_path, pending[]}` |
| `export.guide` | `{platform, browser}` | `{steps[], blocked_by_human[]}` |
| `export.verify` | `{path}` | `{exists, size, sha256, importable}` |
| `clean.index` | `{raw_dir, db_path}` | `{records, roles, dates, errors}` |
| `match.four_way` | `{db_path, out_dir}` | `{report_path, candidates, warnings}` |
| `validate.kit` | `{kit_dir, strict}` | `{ok, findings[]}` |
| `deliver.package` | `{version, out_dir}` | `{zip, sha256, manifest}` |

契约冻结后，WS1 实现入口，WS3/WS4 只按契约调用；改契约走 CONFLICT。

---

## 6. 浏览器 E2E 方案（S4 重点）

### 6.1 三条轨道

| 轨道 | 环境 | 目的 | 证据 |
|---|---|---|---|
| A 干净 Chromium + Playwright | 云端/本地 | 证明“从零安装扩展/脚本 + 注入 + 下载”可跑 | L1–L2 |
| B 本地真实 Edge（脏 profile） | 本地 Windows | 证明“真实登录 + 真实平台 + 真实下载”可跑 | L2–L4 |
| C 云端 browser-use | 云端 | 证明公开页/官方 release 可达；不冒充用户本机 | L1 |

### 6.2 Track A 步骤

1. 下载官方 ScriptCat release zip（浏览器下载，记录 URL/版本/SHA256）。
2. 解压到 `ext/scriptcat`。
3. `launch_persistent_context` + `--disable-extensions-except` + `--load-extension`。
4. 打开 `chrome://extensions`，开 developer mode。
5. 打开详情，开 `Allow User Scripts`；如扩展变 Off，重新启用。
6. 用本地 HTTP server 提供 `afterchat.user.js`；打开 `chrome-extension://.../src/install.html?url=...`。
7. 点主按钮 `Install Script`，确认安装完成页。
8. 打开 ScriptCat 仪表盘，确认 AfterChat v1.25.0 启用。
9. **重载扩展**（developerPrivate.reload）。
10. 打开 mock `/a/chat/s/test-id`，拦截 `history_messages` 返回构造 JSON。
11. 断言 `#m365-export-container` 存在；截图按钮。
12. 点击导出，等 download 事件；保存 `.md`；断言 >0 字节。
13. 用 `01_clean_and_index.py` 导入；查 DB role/time。
14. 断言 metadata model 不重复。

### 6.3 Track B 步骤

1. 用真实 Edge/Chrome，真实 profile，真实登录。
2. 从官方商店/官方 release 安装 ScriptCat + AfterChat。
3. 重载扩展；打开真实 DeepSeek `/a/chat/s/<id>`。
4. 单条导出：点按钮；如弹 Save As，用户点保存；`Ctrl+J` 核对路径/大小。
5. 全部导出：列表页点全部；如进度回退/停滞，标 `needs-human-confirm`；如弹 Save As，标 `blocked-by-human`。
6. 文件落盘后给 SHA256；`01` 导入；DB 查 role/time。
7. 记录真实账号名脱敏、浏览器版本、扩展版本、下载目录。

### 6.4 Track C 步骤

1. 云端 browser-use 打开官方 release/商店页。
2. 记录可达/不可达、按钮状态、下载是否成功。
3. 不登录真实账号；不冒充 Track B。

### 6.5 S4 PASS 判定

- Track A 通过 = L2 smoke，不等于生产。
- Track B 通过 = L2–L4，才算 S4 生产 PASS。
- Track B 无法跑 = `BLOCKED`；不能用 Track A 替代。
- Save As 弹窗 = `blocked-by-human`；批量进度回退 = `needs-human-confirm`；两者都不算 PASS。

---

## 7. PR 拆分与合并顺序

### 7.1 分支/PR

| WS | PR | 内容 | 依赖 | 回滚 |
|---|---|---|---|---|
| WS1 | 1 | release zip + doctor 真建表 | — | 删 release 脚本 |
| WS1 | 2 | wizard declined/consented + 403 人话 | PR1 | 恢复 wizard |
| WS1 | 3 | Agent 入口/契约 + 错误码 | PR2 | 删入口 |
| WS1 | 4 | S1 失败 fixtures | PR2/3 | 删 fixtures |
| WS2 | 1 | 访谈 6 轮 prompt + 语言/选项 | — | 恢复 prompt |
| WS2 | 2 | `[待确认]` 形状 + 追溯 | PR1 | 恢复规则 |
| WS2 | 3 | validator strict/PII/ASCII/禁词 | PR2 | 恢复 validator |
| WS2 | 4 | docs 轮数/依赖一致 | PR3 | 恢复 docs |
| WS3 | 1 | 浏览器手册 + 重载扩展 | — | 恢复手册 |
| WS3 | 2 | export.verify + 下载检测 | PR1 | 删 verify |
| WS3 | 3 | AfterChat adapter model/share | PR1 | 恢复 adapter |
| WS3 | 4 | 01 真实格式 parser + JSONL time | PR1 | 恢复 parser |
| WS3 | 5 | S4 失败 fixtures | PR2/3/4 | 删 fixtures |
| WS4 | 1 | 02 缺/空 DB 错误 | — | 恢复 02 |
| WS4 | 2 | 四路分节 + 候选追溯 | PR1 | 恢复 02 |
| WS4 | 3 | 05 二层三输入/EXPERIMENTAL/签字 | PR1/2 | 恢复 05 |
| WS4 | 4 | S6 fixtures | PR2/3 | 删 fixtures |
| WS5 | 1 | CI 矩阵 Win/Ubuntu Py3.11/3.12 | — | 恢复 CI |
| WS5 | 2 | secret/PII/数据隔离 | PR1 | 恢复扫描 |
| WS5 | 3 | release zip/checksum/rollback | PR1 | 恢复发布脚本 |
| WS5 | 4 | E2E 脚本双平台 | PR3 | 删 E2E |
| WS6 | 1 | 用户手册 + known-limits | — | 恢复手册 |
| WS6 | 2 | 示例 + 盲测脚本 | PR1 | 删示例 |
| WS6 | 3 | 盲测报告 + 文档修复 | PR2 | 恢复文档 |

### 7.2 合并顺序

1. WS1-1/2/3/4；
2. WS2-1/2/3/4；
3. WS3-1/2/3/4/5；
4. WS4-1/2/3/4；
5. WS5-1/2/3/4；
6. WS6-1/2/3。

每合一个 PR：rebase 最新 main → CI → E2E → merge commit → 记录。失败 revert 该 PR，不阻塞其他。

---

## 8. CONFLICT 登记（预判）

| ID | 冲突 | 双方 | 建议裁决 | 状态 |
|---|---|---|---|---|
| C-01 | 下载路径/ Save As 归谁 | WS1 vs WS3 | WS3 拥有浏览器行为；WS1 只包装 CLI，不承诺自动点原生弹窗 | 待 G2 批准 |
| C-02 | `records` schema 改动 | WS3 vs WS4 | 冻结 `rec_id/source_file/created_at/role/content/md5`；改 schema 走 CONFLICT | 待批准 |
| C-03 | PII 规则重复 | WS2 vs WS5 | `03_validate_kit.py` 是唯一事实源；WS5 只加 secret scan | 待批准 |
| C-04 | 安装文档重复 | WS1 vs WS6 | WS1 写安装章节；WS6 引用，不重写 | 待批准 |
| C-05 | CI 浏览器测试 | WS5 vs WS3 | CI 只跑 Track A mock；Track B 真实路径由 WS3 在 PR 声明“未覆盖” | 待批准 |
| C-06 | 事件时间 vs 提及时间 | WS2 vs WS4 | WS2 在访谈记录里分离；WS4 在索引/匹配里不合并 | 待批准 |

---

## 9. 失败画廊（把真实失败变成回归）

最低要加：

- S1 `release-403`：`RELEASE_FETCH_FAILED` + exit 2；
- S1 `wizard-declined`：exit 3 + marker；
- S2 `interview-skeleton`：轮数/dated/L4 不足；
- S2 `pending-un traceable`：无出处/原文；
- S3 `kit-five-files`：`MISSING required file`；
- S3 `kit-pii`：手机号/身份证/ghp_/AKIA；
- S3 `kit-ascii`：strict fail；
- S4 `afterchat-no-reload`：按钮不出现；
- S4 `save-as-dialog`：blocked-by-human；
- S4 `batch-progress-reset`：needs-human-confirm；
- S5 `empty-raw`：`INDEX_EMPTY`；
- S5 `jsonl-time-missing`：unknown=0 失败；
- S6 `missing-db`：`FOUR_WAY_DB_NOT_FOUND`；
- S6 `mock-2-records`：不得生产 PASS；
- S9 `self-approve`：审查拒绝；
- S10 `closed-not-merged`：发布门禁拒绝。

每个 fixture 进 CI，修完不删。

---

## 10. CI 矩阵

| Job | OS | Python | 内容 |
|---|---|---|---|
| unit | Ubuntu 24.04 | 3.11/3.12 | pytest |
| unit-win | Windows 11 | 3.11/3.12 | pytest |
| doctor | 双平台 | 3.12 | doctor + FTS5/trigram |
| failure-paths | 双平台 | 3.12 | 空 raw/缺 DB/五文件/PII/ASCII/wizard |
| browser-smoke | Ubuntu | 3.12 | Chromium + ScriptCat + AfterChat + mock route；按钮 + 下载 + 01 导入 |
| secret-scan | Ubuntu | — | gitleaks/trufflehog 或 regex |
| data-isolation | Ubuntu | — | `git ls-files` 不含 raw/work/*.db/真实访谈 |
| release | Ubuntu | 3.12 | zip + sha256 + rollback 脚本检查 |

真实登录、真实平台、Save As 不在 CI；PR 必须声明。

---

## 11. 发布与回滚

### 发布物

- `xh-dossier-<version>.zip`
- `SHA256SUMS`
- `VERSION`
- `CHANGELOG.md`
- `known-limits.md`
- `rollback.md`
- 用户手册

### 回滚

- 保留上一版 zip；
- `rollback.md` 写：停用新版本 → 解压旧版 → 恢复 `work/` 数据 → `doctor`；
- 回滚不删用户 `raw/`；
- 回滚演练一次，记录时间/结果。

### 发布门禁

- Windows 11 + Ubuntu 24.04；
- 0 P0；P1 修复或用户接受；
- CLOSED issue 修复在分支；
- 校验和可复算；
- 用户批准。

---

## 12. 风险

| 风险 | 影响 | 应对 |
|---|---|---|
| 本地 Edge 继续离线 | S4/S8 无法生产 PASS | 用户重新上线；否则 G4 不通过 |
| Save As 原生弹窗无法自动点 | 用户以为导出失败 | 文档 + `blocked-by-human` 分类；`Ctrl+J` 检查 |
| 商店不可达 | 安装路径不通 | 官方 release fallback；记录环境限制 |
| share URL 不支持 | 用户分享链接打不开 | known-limits；后续 issue |
| mock 被当真实 | 发布假 PASS | 证据分级；S4 必须 Track B |
| 6 个 Agent 上下文污染 | 重复 issue/冲突 | 体验包不含已知 issue；H3 并发避让 |
| 一 issue 多 commit | 无法回退 | S9 门禁；rev-list 核对 |
| raw/PII 进仓库 | 隐私事故 | H4 门禁 + secret scan |

---

## 13. 需要用户拍板的 6 件事（G0/G2）

1. **Save As 算不算可接受摩擦？** 建议：算 `blocked-by-human`，不算失败；用户自己点保存。若不同意，需要改 AfterChat/浏览器策略。
2. **share URL 是否 R0 支持？** 建议：R0 写 known-limit，不阻塞发布；后续 issue。
3. **模型字段重复前缀修在哪？** 建议：优先给 AfterChat 上游提 issue；本地包装层加兼容；R0 不阻塞。
4. **本地 Edge 什么时候能上线？** 没有它，S4/S8 只能 BLOCKED，G4 不能过。
5. **时间能力哪些是模拟、哪些真支持？** 需要写进 `known-limits.md`；建议只承诺“有日期的事件”，不承诺“精确到分钟”。
6. **是否接受 `PASS-WITH-FRICTION`？** 建议接受：Must 全过、Target 缺、用户知情；但不接受 P0 带病发布。

---

## 14. 冻结检查清单（G2）

- [ ] 6 份体验报告齐；
- [ ] 每个 PASS 有证据级别；
- [ ] 每个 FAIL 有 issue + fixture；
- [ ] 每个 CONFLICT 有裁决；
- [ ] issue 表 P0/P1/P2 + owner + 依赖；
- [ ] PR 拆分 <=400 行；
- [ ] CI 矩阵含双平台 + browser-smoke；
- [ ] 失败画廊清单；
- [ ] 数据隔离门禁；
- [ ] 回滚演练；
- [ ] 用户批准日期/签名。

---

## 15. 下一步

1. 用户看这份 + `02-成功标准-v6.md` + `03-提示词-v6.md`；
2. 用户回答第 13 节 6 个问题；
3. G0 通过后，总控发 6 个体验包；
4. 体验报告回来，总控写冻结版 `global-plan`；
5. G2 通过后，才派实现 Agent。
