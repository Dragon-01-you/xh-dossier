# 模板 · 体验报告 / issue / CONFLICT（v6）

> 每个 Agent 复制对应模板填写，不要自由发挥格式。

---

## 1. 体验报告模板

```md
# 体验报告 · <WS-ID> <WS-NAME>

- Agent：<AGENT-ID>
- 日期：<YYYY-MM-DD>
- 环境：<OS / 浏览器 / Python / 仓库 commit>
- 证据级别上限：L1 / L2 / L3 / L4
- 我最远走到：S<N>
- 结论：PASS / PASS-WITH-FRICTION / FAIL / BLOCKED

## 0. 我测了什么（3 行）

## 1. 我没测到什么（3 行）

## 2. 逐步结果

| 步骤 | 结果 | 证据级别 | 关键证据 | 备注 |
|---|---|---|---|---|
| S0 | PASS/FAIL/BLOCKED | L1-L4 | `evidence/S0/...` | |
| S1 | | | | |
| ... | | | | |

## 3. 卡点清单

| # | 卡在哪 | 现象 | 我第一时间以为 | 实际原因 | 证据 |
|---|---|---|---|---|---|
| 1 | | | | | |

## 4. 真实 vs 模拟

| 数据/环节 | real-user / simulated / mock | 说明 |
|---|---|---|
| | | |

## 5. 介入计数

| 类型 | 次数 | 是否 blocked-by-human |
|---|---|---|
| 登录 | | |
| 验证码 | | |
| 系统弹窗 | | |
| 扩展授权 | | |
| 其他 | | |

## 6. 我认为的 P0/P1/P2

| 优先级 | 问题 | 为什么 |
|---|---|---|
| P0 | | |

## 7. 附：证据索引

| 文件 | 内容 | SHA256 |
|---|---|---|
| | | |
```

---

## 2. issue 模板

```md
# <LOCAL-ID> · <现象标题>

- 步骤：S<N>
- 环境：<OS / 浏览器 / 扩展版本 / profile 类别 / commit>
- 证据级别：L1 / L2 / L3 / L4
- 影响：P0 / P1 / P2

## 现象

<最少复现步骤 + 实际看到什么>

## 期望

<按成功标准，应该怎样>

## 实际

<实际输出/截图/文件大小/DB 查询>

## 证据

- `evidence/...`：<说明>
- 命令：`<command>`
- exit code：<n>
- 文件 SHA256：<hash>
- DB 查询：`<sql>` -> <输出>

## 验收

- [ ] <命令/点击> 得到 <期望>
- [ ] 失败 fixture：<name>
- [ ] 独立 Agent 复现：<who/where>

## 不做

- <明确不修的范围>
```

---

## 3. CONFLICT 模板

```md
# CONFLICT-<NN> · <一句话>

- 双方：<WS-A> vs <WS-B>
- 冲突点：<文件/接口/数据格式/文档口径>
- 发现时间：<YYYY-MM-DD>
- 阻塞什么：<哪张票/哪个 PR>

## A 方案

<做法、代价、风险>

## B 方案

<做法、代价、风险>

## 建议裁决

<总控建议 + 理由>

## 等谁拍板

- [ ] 总控
- [ ] 用户
- [ ] 原项目 AI

## 裁决记录

<日期 / 结论 / 谁拍的>
```

---

## 4. 证据命名

```
evidence/
  S0/baseline.json
  S0/network.log
  S0/extensions.json
  S1/doctor-<date>.log
  S1/wizard-declined-<date>.log
  S2/interview-<date>.md
  S3/validate-<date>.log
  S4/single-export-<date>.log
  S4/all-export-<date>.log
  S4/download-dir-<date>.png
  S5/index-<date>.log
  S5/db-query-<date>.txt
  S6/fourway-<date>.log
  S7/validate-legal-<date>.log
  S8/agent-dialogue-<date>.md
```

规则：

- 日期用 `YYYYMMDD`；
- 同一步骤多个证据加序号；
- 大文件（zip/db）不进仓库，只留路径 + SHA256；
- 截图含账号名/头像要打码；
- 日志不含 token/cookie/手机号/身份证。

---

## 5. PASS 表模板（总控汇总用）

| WS | 步骤 | 结果 | 证据级别 | 真实/mock | 备注 |
|---|---|---|---|---|---|
| WS1 | S1 | PASS | L2 | real | |
| WS3 | S4 | BLOCKED | L1 | mock | 等本地 Edge |
| ... | | | | | |

规则：

- 只有 L1 的 PASS 标 `smoke-only`；
- BLOCKED 写缺什么；
- PASS-WITH-FRICTION 写用户是否接受；
- 任何 P0 未解决，整行不能写 PASS。

---

## 6. 发布门禁表模板

| 检查 | 结果 | 证据 | 谁确认 |
|---|---|---|---|
| Windows 11 干净安装 | | | |
| Ubuntu 24.04 干净安装 | | | |
| DOCTOR_OK | | | |
| SMOKE_OK | | | |
| VALIDATE_OK | | | |
| 0 P0 | | | |
| P1 修复/接受 | | | |
| 校验和 | | | |
| 回滚演练 | | | |
| CLOSED issue 在分支 | | | |
| 用户批准 | | | |
```
