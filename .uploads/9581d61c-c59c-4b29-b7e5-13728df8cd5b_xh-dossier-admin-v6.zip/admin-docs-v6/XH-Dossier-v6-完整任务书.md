# XH-Dossier 多 AI 并行任务书 · v6 完整版

> 生成日期：2026-11-22 · 状态：G0 待批准
> 本文件是 00–06 的合集，方便一次性分享；分文件版本在同一目录。

---

# 00 · 总览

## 总览 · 一页看懂（v6）

### 现在的问题

之前只有一个粗标准：“能跑通”。但没人能回答：

- 哪一步算真的过了？
- 按钮出现但没文件，算不算过？
- 命令没报错但结果错，算不算过？
- mock 跑通，能不能说真实用户能跑？

所以 v6 先把“每一步怎样算好”写死，再派 Agent。

### 这版怎么解决

1. **S0–S10 每一步都有 Must / Target / PASS / FAIL / 证据级别。**
2. **证据分 L1–L4**：L1 命令输出，L2 真实数据，L3 独立复现，L4 用户在场。
3. **体验包与实施包分开**：体验 Agent 不看已知 issue，避免“照着答案测”。
4. **6 个 Workstream 并行跑完整流程**：安装、访谈、浏览器导出、清洗匹配、CI/发布、文档盲测。
5. **6 份报告汇总成 global-plan，用户批准后才实施**。
6. **实施阶段一 issue 一分支一 PR，独立审查，统一合并**。
7. **G0–G4 门禁**：标准冻结 → 报告齐 → 方案冻结 → PR/CI/审查 → 合并/E2E → 用户批准发布。

### 当前实测到哪

- 云端机械层：`pytest` 33 passed；wizard/validate/清洗/匹配都跑了。
- 云端干净 Chromium：ScriptCat 1.5.2 + AfterChat 1.25.0 装成功；重载后按钮出现；mock 导出 374 bytes；`01` 导入 2 条；role/time 正确。
- 真实 DeepSeek 登录态：没有；`blocked-by-human`。
- 本地 Edge：环境离线；真实导出/盲测没跑。
- 所以：**最多 L1–L2 smoke，不能写生产 PASS。**

### 需要你拍板的 6 件事

1. Save As 原生弹窗算不算可接受摩擦？（建议算 blocked-by-human）
2. 分享页 `/share/` 是否 R0 支持？（建议写 known-limit）
3. `Model` 重复前缀修在哪？（建议上游 issue + 本地兼容）
4. 本地 Edge 什么时候能上线？（没有它 G4 过不了）
5. 时间能力哪些是模拟、哪些真支持？（写 known-limits）
6. 是否接受 `PASS-WITH-FRICTION`？（建议接受，但不接受 P0 带病发布）

### 你批准后我做什么

1. 发 6 个体验包（不含已知 issue）。
2. 收 6 份报告 + issue + 证据。
3. 汇总 `global-plan` 给你看。
4. 你说“方案没问题”，我再派实现 Agent。
5. 多 PR + CI + 独立审查 + 原项目 AI 深审 + 统一合并 + 双平台 E2E。
6. 你批准后发布。

### 文件

- `01-任务书-v6.md`：角色、阶段、门禁、6 个 Workstream。
- `02-成功标准-v6.md`：每一步怎样算好。
- `03-提示词-v6.md`：6 类 Agent 的复制即用提示词。
- `04-global-plan-v6.md`：整体方案草案 + 问题表 + PR 拆分。
- `05-实测记录-v6.md`：本轮真实跑的证据。
- `06-模板-体验报告与issue.md`：报告/issue/CONFLICT 模板。

---

# 01 · 任务书

## 任务书 · 多 AI 并行体验与实施（v6）

> 版本：v6 · 2026-11-22
> 状态：**待用户批准 G0（标准冻结）**。未批准前不派实施 Agent。
> 适用仓库：`Dragon-01-you/xh-dossier`（MIT）
> 这份文件给三类人看：用户（批准）、总控 AI（拆包/汇总）、Workstream Owner（执行）。体验 Agent 只看“体验包”部分，不看已知 issue。

---

### 0. 一句话目标

把 XH-Dossier 从“开发者本机能跑”推进到“普通用户只跟本地 AI Agent 对话，就能完成安装 → 访谈 → 导出 → 清洗 → 校验 → 拿到可用档案”。

不做 GUI，不绑定 Dify，raw 默认留在用户本机。交付物是：

1. release zip / 安装入口；
2. 本地 Agent 可调用的受控工具契约；
3. 6 文件 Kit；
4. 每一步都能被证据验收的记录。

---

### 1. 相比 v3，这版改了什么

| 改动 | v3 | v6 |
|---|---|---|
| 成功标准 | 一个粗标准 + 验收摘要 | **S0–S10 每一步都有 Must / Target / PASS / FAIL / 证据级别** |
| 体验与实施 | 混在一起 | **体验包 / 实施包分离**：体验 Agent 不看已知 issue、不看修复分支、不看预期结论 |
| 证据 | “跑过了” | **H1 证据分级 L1–L4**：L1 只算“命令跑了”，不能写生产级 PASS |
| 失败路径 | 顺带提 | **H2 失败画廊**：每一步至少 1 个真实失败 fixture，进 CI 回归 |
| 并发 | 口头避让 | **H3 并发避让**：开工前比对 open issue/PR，已认领/已关闭不重复做 |
| 数据 | 靠自觉 | **H4 数据隔离门禁**：`git ls-files` 不含 raw/work/*.db/真实访谈；fixture 过敏感扫描 |
| 浏览器 | 一句“浏览器导出” | **环境矩阵**：干净 Chromium / 本地真实 Edge / 云端 browser-use 三者分开，谁能证明什么写清楚 |
| 门禁 | 无 | **G0–G4**：标准冻结 → 体验报告齐 → 方案冻结 → PR/CI/独立审查 → 合并/E2E → 用户批准发布 |

---

### 2. 铁律（违反任何一条，本轮结果作废）

1. **没有标准不开工**。每一步开工前，先能回答“怎样算 PASS、拿什么证据、什么算 FAIL”。
2. **没有证据不说 PASS**。命令 exit 0 不等于结果对；截图不等于文件落盘；mock 不等于真实平台。
3. **体验 Agent 不看已知答案**。派发包里不写 issue 编号、不写已知缺陷、不写预期结论、不写修复分支。体验 Agent 只拿发布物、用户视角任务书、成功标准。
4. **作者不自审**。写代码的 Agent 不能给自己 PR 点通过；独立审查 Agent 必须 fresh context，只拿 diff、spec、标准。
5. **一 issue 一分支一 PR 一 commit（可回退）**。大 issue 可拆，但每个 PR 必须能单独 revert。
6. **不碰 `D:\芯火剪辑系统`**。不在那里 git init、不提交、不推送、不做实验。
7. **raw 留本机**。不上传原始对话、不把真实访谈/真实账号写进仓库、日志不含真实用户名/token/手机号/身份证。
8. **登录/验证码/付费/系统原生弹窗 = blocked-by-human**。不伪造通过，不算 FAIL，单列不计入“≤3 次介入”。
9. **高风险 PR 停“待强审”**。涉及数据模型、删除/迁移、权限、发布脚本、CI 密钥的 PR，必须原项目 AI + 用户一起看。
10. **用户批准后才 tag/release**。

---

### 3. 角色与边界

| 角色 | 目录/身份 | 做什么 | 不做什么 |
|---|---|---|---|
| 用户 | — | 批准 G0/G2/G4；回答产品决策；真实登录 | 不被要求看终端、装 Python、改配置 |
| 总控 AI | 本对话 | 拆包、汇总 `global-plan`、跟踪门禁、统一合并 | 不替 Workstream Owner 写实现细节 |
| 行政部 | `D:\xh_auto\xh-admin` | 目标、spec、issue、evidence、验收、发布记录 | 不写代码 |
| 工程部 | `D:\xh_auto\xh-dossier` | 技术规划、拆任务、派实现 Agent、写代码、自测、PR、CI | 不自审、不跳过失败路径 |
| 盲审部 | `D:\xh_auto\xh-blind` | 只拿发布物/用户流程，从普通用户视角盲测 | 不看作者解释、不看已知 issue |
| 独立审查部 | `D:\xh_auto\xh-review` | 独立审 PR 的 Spec / Standards / Security；最终多 Agent 审计 | 不改代码、不替作者解释 |
| 发布门禁 | 行政部 + 独立审查部 + 用户 | 核对 G4、校验和、回滚、0 P0、用户批准 | 不是第五个部门，是联合放行 |

`D:\芯火剪辑系统` 只作为**禁止进入的边界**，不参与任务。

---

### 4. 阶段与门禁

```
G0 标准冻结
  └→ Phase 0 真实体验（并行 6 个 Workstream Owner）
       └→ G1 体验报告齐（每人一份 report + issue + evidence）
            └→ Phase 1 issue / CONFLICT 汇总
                 └→ Phase 2 总控写 global-plan
                      └→ G2 方案冻结（用户批准）
                           └→ Phase 3 并行实施（多 PR + CI）
                                └→ G3 独立审查（每 PR 双轴 + 安全）
                                     └→ Phase 4 原项目 AI 深审
                                          └→ Phase 5 统一合并 + 完整 E2E
                                               └→ G4 用户批准
                                                    └→ 发布
```

#### G0 标准冻结（本轮要先过的门）

必须同时满足：

- `01-任务书-v6.md`、`02-成功标准-v6.md`、`03-提示词-v6.md` 三份文件用户已读；
- 用户明确说“标准没问题，可以按这个跑”；
- 体验包不含已知 issue/预期结论；
- 6 个 Workstream 的边界、产出目录、验收人已写死；
- 本地/云端/浏览器三种环境的“能证明什么”已写死。

G0 未过，不派任何体验 Agent。

#### G1 体验报告齐

每个 Workstream Owner 必须交：

- `baseline.json`（S0 七项）；
- `experience-report.md`（按模板，逐步 PASS/FAIL/BLOCKED + 证据级别）；
- `issues/ISSUE-*.md`（只写自己遇到的，不抄已知 issue）；
- `conflicts/CONFLICT-*.md`（跨 Workstream 冲突）；
- `evidence/<step>/...`（命令输出、截图、文件 hash、DB 查询结果）。

缺一份 = G1 不过。

#### G2 方案冻结

总控把 6 份报告合并成 `global-plan.md`，必须包含：

- 体验矩阵（谁跑通/谁 blocked/证据级别）；
- issue 表（现有 + 新发现，P0/P1/P2，owner，依赖）；
- Workstream 任务卡（文件范围、验收命令、PR 拆分）；
- CONFLICT 裁决；
- 合并顺序与回滚策略；
- 明确“不做什么”。

用户说“方案没问题，可以实施” = G2 过。

#### G3 独立审查

每个 PR 必须：

- CI 绿（Windows + Ubuntu，Python 3.11/3.12）；
- PR body 有 Summary / Evidence / Risk / How to revert / CI 未覆盖的真实路径；
- 至少 1 名非作者审查 Agent 给 `REVIEW_PASS`；
- 高风险 PR 有原项目 AI 的 `DEEP_REVIEW_PASS`；
- 没有 P0/P1 未解决（P1 可带“用户接受”的记录）。

#### G4 发布批准

必须同时满足：

- Windows 11 + Ubuntu 24.04 干净环境都跑 `DOCTOR_OK` + `SMOKE_OK` + `VALIDATE_OK`；
- release zip + `SHA256SUMS` + `VERSION` + `CHANGELOG`；
- 0 个 P0；P1 全部修复或有用户接受的 known-limits；
- 回滚步骤可执行；
- 所有 CLOSED issue 的修复确实进了待发布分支；
- 用户明确说“可以发布”。

---

### 5. Phase 0：真实体验（体验包）

#### 5.1 体验包发什么

只发以下内容，**不发** issue 列表、PR、修复分支、作者解释、预期结论：

1. 本任务书第 5 节 + 第 10 节对应 Workstream 卡；
2. `02-成功标准-v6.md`；
3. 发布物：release zip 或仓库 clone（固定 commit）+ 安装说明；
4. 用户视角任务：从零开始，像普通用户一样完成一条完整流程；
5. 输出目录模板。

#### 5.2 体验 Agent 怎么跑

每个 Agent 是 **Workstream Owner**，负责一条完整流程，不是只做一张票。可以隔离子 Agent（体验/实现/审查），避免上下文污染。

统一动作：

1. **S0 环境**：按标准记录七项；先不装任何东西。
2. **S1 安装**：从 release zip 或干净 clone 开始；只走用户会走的入口；不直接改代码。
3. **S2 访谈**：真实跑 6 轮；用真实回答或明确标注 `simulated` 的合成回答；不伪造 L4。
4. **S3 Kit**：生成 6 文件；跑 `VALIDATE_OK`；跑 strict；跑失败输入。
5. **S4 导出**：按环境矩阵选路径；扩展/脚本必须从官方商店或官方 release 页面下载；记录 URL/版本/SHA256；单条 + 全部分别验证。
6. **S5 清洗**：`01_clean_and_index.py`；查 DB；跑空/缺 raw/坏 JSONL。
7. **S6 匹配**：`02_four_way_match.py`；检查四路分节；缺 DB/空 DB。
8. **S7 校验**：合法不误杀 + 非法能抓住 + PII/ASCII 拦截。
9. **S8 Agent 路径**：如果本地有 AI Agent，用对话完成；没有就写“需要什么才能测”，不假装。
10. **收尾**：写 report、issue、CONFLICT、evidence；不修代码。

#### 5.3 体验 Agent 的禁止项

- 不读 `issues/`、`global-plan.md`、PR、fix 分支、CI 失败记录；
- 不搜索“xh-dossier issue”找答案；
- 不把 mock 结果写成真实平台结果；
- 不把“按钮出现”写成“导出成功”；
- 不把“命令没报错”写成 PASS；
- 不把 Save As 弹窗点掉后算自动通过；点不掉就 `blocked-by-human`；
- 不修改 `D:\芯火剪辑系统`。

#### 5.4 体验 Agent 的输出

```
<RUN-DIR>/
  baseline.json
  experience-report.md
  issues/
    ISSUE-<WS>-01.md
    ...
  conflicts/
    CONFLICT-01.md
  evidence/
    S0/...
    S1/...
    ...
    S8/...
  artifacts/
    kit/
    raw/
    work/
```

命名规则：

- `WS1`–`WS6` 对应 6 个 Workstream；
- issue 编号本地递增，不写 GitHub 编号；
- evidence 文件名包含步骤 + 命令 + 日期，例如 `S4/single-export-20261122.log`；
- 大文件（zip、db）不上传仓库，只留本地路径 + SHA256。

---

### 6. Phase 1：issue 与 CONFLICT

#### 6.1 issue 必须写什么

每条 issue 必须包含：

- 标题：现象，不是猜测；
- 步骤：S0–S10 中的哪一步；
- 环境：OS / 浏览器 / 扩展版本 / profile 类别 / commit；
- 复现：最少命令/点击序列；
- 期望 vs 实际；
- 证据：exit code、stdout/stderr、截图、文件 hash、DB 查询；
- 证据级别：L1–L4；
- 影响：P0/P1/P2；
- 验收：修好后用哪条命令/哪次点击证明；
- 不做：明确不修的范围；
- 失败画廊：是否已加入 fixture。

#### 6.2 CONFLICT 必须写什么

- 哪两个 Workstream 冲突；
- 冲突点（文件/接口/数据格式/文档口径）；
- 两种方案及代价；
- 建议裁决；
- 等待谁拍板（总控/用户/原项目 AI）。

#### 6.3 不允许的 issue

- “感觉不对”“可能有问题”没有证据；
- 把已知 issue 换个说法重复提交；
- 把“用户没登录”写成 bug；
- 把 mock 限制写成真实平台 bug；
- 把“CI 没覆盖”写成“功能已坏”。

---

### 7. Phase 2：global-plan 与冻结

总控写 `global-plan.md`，结构固定：

1. 目标与非目标；
2. 体验矩阵（6 个 Workstream × 环境 × 结果 × 证据级别）；
3. issue 表（P0/P1/P2、owner、依赖、验收命令）；
4. Workstream 任务卡；
5. 接口/数据契约；
6. CONFLICT 裁决；
7. PR 拆分与合并顺序；
8. 失败画廊清单；
9. 数据隔离与安全检查；
10. 发布门禁；
11. 风险与回滚；
12. 冻结签名（用户批准日期）。

冻结后，任何范围变更必须走“变更单”，不能边做边加。

---

### 8. Phase 3：并行实施

#### 8.1 工程部怎么拆

每个 Workstream Owner：

1. 读 `global-plan.md` 和本 WS 的 issue；
2. 写 `plan.md`（技术方案、文件范围、风险）；
3. 写 `tasks.md`（每张票：输入/输出/验收命令/依赖）；
4. 派实现子 Agent；每个子 Agent 只拿一张票 + 文件范围 + 验收命令；
5. 每个实现子 Agent 一分支一 PR；
6. Owner 做集成自测，但不做独立审查；
7. 交 PR 列表 + evidence 给独立审查部。

#### 8.2 PR 规则

- 分支：`ws<N>/<short>-<issue-local-id>`；
- commit：`fix(#<github-id>): <what>` 或 `feat(#<id>): <what>`；
- 一个 issue 一个 commit（可 squash）；大 issue 拆多个 PR 时，每个 PR 对应一个子 issue；
- PR <= 400 行 diff（生成文件/测试 fixture 可放宽，需说明）；
- PR body 必须有：

```
### Summary
### Issue
### Evidence (before/after)
### Test commands
### CI run
### Risk
### How to revert
### CI 未覆盖的真实路径
### Checklist
```

- 不许作者自己点 approve；
- 不许红 CI 合并；
- 不许把 raw/真实账号/密钥提交。

#### 8.3 CI 矩阵

- Ubuntu 24.04 + Windows 11；
- Python 3.11 + 3.12；
- `pytest -q`；
- `00_doctor.py`；
- `00_export_wizard.py --yes --dry-run`；
- `03_validate_kit.py --target templates`；
- 失败路径：空 raw、缺 DB、五文件、PII、ASCII、wizard declined；
- secret scan + PII scan；
- **browser-smoke（Linux，clean Chromium + ScriptCat + AfterChat + mock DeepSeek route）**：按钮出现 + 下载文件 >0 字节 + `01` 导入 >=1 条；
- 真实登录/真实平台/Save As 不在 CI 覆盖，PR 必须声明。

---

### 9. Phase 4：独立审查

#### 9.1 独立审查怎么派

总控给审查 Agent 一份“大白话任务”，只写：

- 用户要什么；
- 这版应该做到什么；
- 验收标准；
- PR 列表 + diff；
- 发布物。

**不写**：作者怎么想的、已知 issue 的结论、修复过程、预期通过。

#### 9.2 三条审查轴

1. **Spec**：PR 是否真的实现 issue 的验收；有没有漏用户场景。
2. **Standards**：代码规范、错误处理、测试、文档一致性、跨平台。
3. **Security / Data**：raw/PII/密钥、路径注入、下载目录、权限、日志脱敏。

#### 9.3 审查输出

每条 finding：

- 文件:行；
- 严重度 P0/P1/P2；
- 证据（命令/输入/输出）；
- 置信度；
- 建议修法；
- 是否已复现（必须实际复现边界输入，不接受“看代码觉得”）。

审查结论只能是：

- `REVIEW_PASS`：所有 Must 过，证据 >= L2；
- `REVIEW_PASS_WITH_FRICTION`：Must 过，但 Target 缺，用户可接受；
- `REVIEW_FAIL`：有 Must 缺 / P0；
- `BLOCKED`：缺环境/权限，无法判断。

#### 9.4 原项目 AI 深审

原项目 AI（最了解架构的 Agent）必须：

- 读 global-plan、所有 issue、所有 PR；
- 查架构兼容、数据模型、迁移、历史决策；
- 在最新 main 上跑完整 E2E；
- 核对 CI 未覆盖的真实路径；
- 给 `DEEP_REVIEW_PASS` / `DEEP_REVIEW_HOLD`；
- 高风险 PR 必须 `HOLD` 到用户确认。

#### 9.5 多 Agent 审计

至少 3 个独立 Agent：

- A：Spec 轴；
- B：Standards 轴；
- C：Security/Data 轴。

三者都 PASS 才能进合并；任一 FAIL，回到实现。

---

### 10. Phase 5：合并与发布

#### 10.1 合并顺序

1. 基础契约 / 错误处理（WS1）；
2. Kit / 校验（WS2）；
3. 浏览器导出 / 导入清洗（WS3）；
4. 四路匹配 / 回填（WS4）；
5. CI / 安全 / 发布脚本（WS5）；
6. 文档 / 示例 / 盲测（WS6）。

每合一个 PR：

- rebase 最新 main；
- 重跑 CI；
- 跑一次 E2E；
- 记录 merge commit；
- 失败则 revert 该 PR，不阻塞其他。

#### 10.2 发布前完整 E2E

必须在一个干净环境从零跑：

1. 下载 release zip；
2. 解压；
3. `00_doctor.py`；
4. 访谈 6 轮；
5. 生成 Kit；
6. `03_validate_kit.py --strict`；
7. 浏览器装扩展 + 脚本；
8. 单条导出 + 全部导出；
9. `01_clean_and_index.py`；
10. `02_four_way_match.py`；
11. 打开报告；
12. 卸载/回滚验证。

#### 10.3 发布物

- `xh-dossier-<version>.zip`；
- `SHA256SUMS`；
- `VERSION`；
- `CHANGELOG.md`；
- `known-limits.md`（含 Save As、share URL、模拟时间能力）；
- `rollback.md`；
- 安装/使用手册（普通用户语言）。

#### 10.4 发布门禁

- 0 P0；
- P1 全部修复或用户书面接受；
- Windows + Ubuntu 双跑通过；
- 校验和可复算；
- 回滚可执行；
- CLOSED issue 的修复在待发布分支；
- 用户明确批准。

---

### 11. 环境矩阵（浏览器重点）

| 环境 | 能证明什么 | 不能证明什么 | 证据级别 |
|---|---|---|---|
| 干净 Chromium + Playwright（云端/本地） | 扩展安装、userScripts 开关、脚本注入、mock API 导出、文件落盘、`01` 导入 | 真实登录、真实平台 UI、真实 Save As、普通用户摩擦 | L1–L2 |
| 本地真实 Edge/Chrome（脏 profile） | 真实登录、真实平台、真实下载目录、Save As、扩展商店 | 不能证明“干净用户第一次” | L2–L4 |
| 云端 browser-use（独立 Chrome） | 公开页面可访问、官方 release 可下载、商店是否可达 | 不能冒充普通用户本机；不能读本地登录态 | L1 |
| 本地 AI Agent 对话 | 用户零终端、介入次数、错误可读性 | 不能替代真实浏览器登录 | L3–L4 |

#### 浏览器路径规则

1. 扩展/用户脚本必须从**官方商店或官方 release 页面**通过浏览器下载；记录 URL、版本、SHA256。
2. 禁止 `curl` 直接拉 CRX 冒充用户路径。
3. 商店不可达时：
   - 记录 `STORE_UNREACHABLE`；
   - 改用官方 GitHub release；
   - 不把“GitHub release 能装”写成“商店路径已通过”。
4. 扩展安装后：
   - 开开发者模式；
   - 开 `Allow User Scripts`；
   - 装 AfterChat；
   - **重载一次扩展**；
   - 再打开目标页；
   - 确认按钮出现。
5. 单条导出和全部导出分开验证：
   - 单条：会话页 `.md` >0 字节；
   - 全部：列表页 `.zip` >0 字节，含多个 `.md`；
   - 每次 `Ctrl+J` 核对下载路径/大小；
   - 不写死下载目录。
6. Save As 原生弹窗 = `blocked-by-human`；批量进度回退/停滞 = `needs-human-confirm`；两者都不算 PASS。
7. 真实登录/验证码 = `blocked-by-human`；不伪造、不绕。

---

### 12. 6 个 Workstream 卡（体验阶段）

> 每张卡只写“你负责哪条完整流程、必须产出什么、不能做什么”。不写已知 issue。

#### WS1 · 安装 / doctor / Agent 契约

- 范围：release zip、`00_doctor.py`、`00_export_wizard.py`、依赖检查、错误文案、Agent 可调用入口。
- 必须跑：干净目录安装 → doctor → wizard declined/consented → 失败依赖 → 无网络/403。
- 产出：`baseline.json`、`experience-report.md`、`issues/`、`evidence/S0-S1/`。
- 不能做：不修业务代码；不把“命令能跑”当安装成功。

#### WS2 · 访谈 / Kit / 校验

- 范围：6 轮访谈、6 文件 Kit、`03_validate_kit.py`、`[待确认]` 追溯、PII/ASCII/禁词。
- 必须跑：真实/模拟访谈 6 轮 → 生成 Kit → `VALIDATE_OK` → strict → 五文件/PII/ASCII/假日期 → 合法样本不误杀。
- 产出：访谈记录、Kit、validate 日志、issue、evidence。
- 不能做：不编造 L4；不把模板当成品；不把 `[待确认]` 写成无出处。

#### WS3 · 浏览器导出 / 导入清洗

- 范围：扩展安装、AfterChat、单条/全部导出、下载落盘、`01_clean_and_index.py`、真实格式解析。
- 必须跑：官方商店/release 下载 → 安装 → 重载 → 按钮 → 单条 `.md` → 全部 `.zip` → `Ctrl+J` → `01` 导入 → DB 查角色/时间。
- 产出：扩展清单、下载 URL/版本/SHA256、文件 hash、DB 查询、issue、evidence。
- 不能做：不用 curl 拉 CRX；不把 mock 当真实；不把按钮出现当导出成功。

#### WS4 · 四路匹配 / 二层回填

- 范围：`02_four_way_match.py`、四路分节、缺 DB/空 DB、`05_deep_backfill`、needs_llm、签字状态。
- 必须跑：2 条 mock → 四路；空 DB → 错误；缺 DB → 错误；二层三输入 → EXPERIMENTAL；无确认不写回。
- 产出：报告、候选、DB 查询、issue、evidence。
- 不能做：不把 2 条 mock 的 `FOUR_WAY_OK` 当生产 PASS；不把模型猜测写回正式档案。

#### WS5 · CI / 安全 / 发布

- 范围：CI 矩阵、secret/PII 扫描、数据隔离、release zip、校验和、回滚、双平台。
- 必须跑：`git ls-files` 检查；secret scan；Windows/Ubuntu 双跑；release 构建；校验和；回滚演练。
- 产出：CI 配置、扫描报告、release 清单、rollback、issue、evidence。
- 不能做：不把 CI 绿当 E2E；不跳过真实路径声明。

#### WS6 · 文档 / 示例 / 盲测

- 范围：用户手册、known-limits、示例、盲测脚本、普通用户语言。
- 必须跑：只看 release + 手册，从零走一遍；记录卡点/介入；不读源码。
- 产出：盲测报告、文档问题、issue、evidence。
- 不能做：不看作者解释；不把“文档写了”当“用户能做”。

---

### 13. 交付物清单

#### 体验阶段（G1）

- 6 份 `experience-report.md`；
- 6 份 `baseline.json`；
- 所有 `ISSUE-*.md` / `CONFLICT-*.md`；
- 证据目录（命令输出、截图、hash、DB 查询）；
- 一份总控 `experience-matrix.md`。

#### 方案阶段（G2）

- `global-plan.md`（冻结版）；
- `issue-table.md`（P0/P1/P2 + owner + 依赖 + 验收）；
- `interface-contract.md`（工具入参/出参/退出码/文件布局）；
- `pr-plan.md`（分支/PR/合并顺序/回滚）。

#### 实施阶段（G3）

- 每个 PR 的 body + CI run + evidence；
- 每个 PR 的独立审查报告；
- 原项目 AI 深审报告；
- `merge-log.md`。

#### 发布阶段（G4）

- release zip + SHA256SUMS + VERSION + CHANGELOG；
- `known-limits.md` + `rollback.md`；
- 双平台 E2E 日志；
- 用户批准记录。

---

### 14. 用户批准页（G0）

请用户只回答三件事：

1. 这份任务书的边界对不对？（不做 GUI、不绑 Dify、raw 留本机、不碰剪辑 Git）
2. `02-成功标准-v6.md` 的 Must/PASS 有没有要加的？
3. 是否同意按“6 个 Workstream 并行体验 → 汇总 issue → 冻结方案 → 并行实施”的顺序跑？

用户说“可以”，即 G0 通过。总控随后发体验包，不先问零散问题。

---

### 15. 附：本轮已实测事实（供总控，不发给体验 Agent）

- 云端 clone `97c192b`，`pytest` 33 passed；本地 `1fa699e`，32 passed（落后一个 commit）。
- 云端干净 Chromium 已装 ScriptCat 1.5.2 + AfterChat 1.25.0；重载扩展后 mock 页面按钮出现，导出 `Mock Conversation.md` 374 bytes；`01` 导入 2 条，角色/时间正确；`02` 输出 `FOUR_WAY_OK records=2`。
- 真实 DeepSeek 分享页 `/share/...` 不注入按钮；`/a/chat/s/...` 无登录态跳登录页；真实登录未完成（blocked-by-human）。
- `--download-release` 在 GitHub API 403 时输出原始 traceback；`03 --strict` 能抓 ASCII 占位符；`00_export_wizard` declined exit 1。
- AfterChat 导出 metadata 出现 `deepseek-deepseek-v4` 重复前缀。
- 本机 Edge 环境当前离线；真实本地导出仍未跑通。

这些事实只用于总控写 `global-plan`，**不得写进体验包**。

---

# 02 · 成功标准

## 成功标准 · 每一步（v6）

> 版本：v6 · 2026-11-22
> 状态：**G0 待批准**。这份文件是“每一步怎样算好”的唯一口径。
> 原则：没有标准不开工；没有证据不说 PASS；命令没报错不等于成功；mock 不等于真实平台。
> 标记：[v5] = 用户原标准；[补充] = 2026-11-22 实战新增；[v6] = 本轮按实测再补。

---

### H1 证据分级（横向，适用于所有步骤）

| 级别 | 证据 | 能支撑的结论 | 不能支撑的结论 |
|---|---|---|---|
| L1 | 命令输出 / exit code / 截图 | “命令跑了”“页面出现了” | “真实数据可用”“用户能完成” |
| L2 | 真实数据跑通（非脱敏样例、非 mock） | “真实数据可用” | “换个人/换台机器也能用” |
| L3 | 独立 Agent 复现（不是作者自证） | “非作者自证，可重复” | “生产级稳定” |
| L4 | 用户在场确认（真实点击/真实登录/真实接受） | “生产级 PASS” | — |

规则：

1. 任何一步的 PASS 必须标证据级别。
2. 只有 L1 就写 PASS，视为违规。
3. 发布级 PASS 至少 L2；关键用户路径（S4/S8）至少 L3 或 L4。
4. mock、合成访谈、模拟时间能力，必须显式标 `simulated`；不得写成 `real-user`。
5. 证据要可复算：文件给 SHA256；DB 给查询语句 + 输出；命令给完整 stdout/stderr + exit code。

---

### H2 失败画廊（横向）

每一步至少 1 个真实失败 fixture，放进 CI，防回归。

要求：

- fixture 来自真实失败，不是编造；
- 每个 fixture 有 `input/`、`expected-error`、`expected-exit`；
- CI 断言错误 marker + 退出码 + 人话提示；
- 修完后 fixture 仍保留，不能删除；
- 新发现的失败，先加 fixture，再修。

最低清单：

| 步骤 | 失败 fixture | 期望 |
|---|---|---|
| S1 | `release-403` | `RELEASE_FETCH_FAILED` + exit 2，无 traceback |
| S1 | `wizard-declined` | `WIZARD_DECLINED` + 非零 |
| S2 | `interview-skeleton` | 轮数/日期/L4 不足，FAIL |
| S2 | `pending-un traceable` | `[待确认]` 无出处/原文，FAIL |
| S3 | `kit-five-files` | `MISSING required file` + 非零 |
| S3 | `kit-pii` | 手机号/身份证/ghp_/AKIA 全 FAIL |
| S3 | `kit-ascii-placeholder` | strict FAIL |
| S4 | `afterchat-no-reload` | 按钮不出现，FAIL |
| S4 | `save-as-dialog` | `blocked-by-human`，不是 PASS |
| S4 | `batch-progress-reset` | `needs-human-confirm`，不是 PASS |
| S5 | `empty-raw` | `INDEX_EMPTY` + 非零 |
| S5 | `jsonl-time-missing` | unknown=0 断言失败 |
| S6 | `missing-db` | `FOUR_WAY_DB_NOT_FOUND` + 非零 |
| S6 | `mock-2-records` | 不得输出生产 PASS |
| S7 | `legal-kit` | 不误杀 |
| S9 | `self-approve` | 审查拒绝 |
| S10 | `closed-not-merged` | 发布门禁拒绝 |

---

### H3 并发避让（横向）

开工前：

1. `gh issue list --state open`；
2. `gh pr list --state open`；
3. 搜 issue/PR 标题关键词；
4. 看 labels：`status:claimed`、`status:needs-info`、`risk:high`。

规则：

- 已认领/已 CLOSED 的，不重复做，只引用；
- 同一文件同一时间只允许一个 Owner；
- 跨文件改动先写 `CONFLICT`；
- 分支存活不超过 2 天，日更 rebase；
- 合并串行，不并行合并。

---

### H4 数据隔离门禁（横向）

必须通过：

1. `git ls-files` 不含：
   - `raw/`、`work/`、`*.db`；
   - 真实访谈记录、真实账号、真实导出；
   - 浏览器 profile、cookie、token。
2. 所有 fixture 为脱敏/合成；
3. 日志不含真实用户名/账号/token/手机号/身份证；
4. secret scan 通过；
5. 截图中的账号名/头像打码或裁掉；
6. raw 只在用户本机，release 包不含 raw。

任何一条不过 = 发布门禁 FAIL。

---

### G0–G4 阶段门禁

| 门 | 必须满足 | 不通过怎么办 |
|---|---|---|
| G0 标准冻结 | 任务书 + 本标准 + 提示词用户已读并同意；体验包无已知 issue | 不派 Agent |
| G1 体验报告齐 | 6 份 report + baseline + issue + evidence | 缺谁补谁，不进入汇总 |
| G2 方案冻结 | global-plan 含体验矩阵/issue 表/任务卡/冲突裁决/合并顺序；用户批准 | 不实施 |
| G3 PR/CI/独立审查 | 每 PR CI 绿 + 非作者 REVIEW_PASS + 高风险 DEEP_REVIEW_PASS | 不合并 |
| G4 发布批准 | 双平台 E2E + 校验和 + 0 P0 + 回滚 + 用户批准 | 不发布 |

---

### S0 环境

**目标**：任何人拿到记录，能在同版本环境复现同一结果。

#### Must

- [v5] S0.1 记录 OS/版本/架构、Python、Node、Git、浏览器版本、仓库 URL/commit、工作目录、日期。
- [v5] S0.2 记录 profile 类别：`clean`（新 profile，无扩展、无登录）或 `dirty`（真实用户 profile）。不能写“默认”。
- [补充 S0.4] S0.3 扩展清单：名字 / ID / 版本 / 启用状态 / 来源 URL；没有扩展写“无”。
- [补充 S0.4] S0.4 实际脚本管理器：ScriptCat / Tampermonkey / Violentmonkey / 无；版本；`Allow User Scripts` / developer mode 状态。
- [补充 S0.4] S0.5 登录态：平台 + 是否登录 + 账号名（可脱敏 `D***`）；不记录 cookie/token。
- [补充 S0.5] S0.6 三件网络事实分别记录，不得合并：
  - `curl -I https://github.com` 结果；
  - 浏览器打开目标站结果（截图 + HTTP/标题）；
  - `git push --dry-run` 是否被策略拦。
- [v6] S0.7 原始输出落盘：`baseline.json` + `network.log` + `extensions.json` + `browser-version.txt`。

#### PASS

七项齐全；换一个 Agent 按记录能复现；任何一项缺 = FAIL。

#### FAIL / 常见假 PASS

- 只写“环境正常”；
- 把云端 browser-use 当本地真实浏览器；
- 把 mock 当真实平台；
- 只记录 `curl` 成功，没记录浏览器是否可达；
- 登录态写“已登录”但没有账号名/截图。

#### 证据级别

L1 至少；S0.6 浏览器访问需 L2 截图；真实登录态需 L4 用户确认。

---

### S1 安装 / doctor

**目标**：普通用户在干净环境能装、能自检、出错能看懂。

#### Must

- [v5] S1.1 `00_doctor.py` exit 0 + 输出 `DOCTOR_OK`。
- [v5] S1.2 Python >= 3.11；SQLite FTS5 与 trigram **真建表 + 插入 + 查询**，输出临时表名/查询结果；不是 `import sqlite3` 就算。
- [v5] S1.3 工作目录可写；模板/脚本/依赖存在；缺依赖给人话 + 非零退出。
- [补充 S1.3] S1.4 同意门禁语义：
  - declined → 非零 exit + `WIZARD_DECLINED`；
  - consented → exit 0；
  - `--dry-run` 不写盘、exit 0。
- [v6] S1.5 从 release zip 在干净目录安装，不依赖仓库源码；`doctor` 结果与仓库内一致。
- [v6] S1.6 `--download-release` 在 GitHub API 403/超时/断网时，输出 `RELEASE_FETCH_FAILED` + 可操作提示 + exit 2；**不得输出原始 traceback**。

#### PASS

- 干净目录安装成功；
- `DOCTOR_OK`；
- FTS5/trigram 真建表；
- declined/consented/dry-run 三种退出码正确；
- 403/断网人话错误；
- 所有命令 + exit code + stdout/stderr 落盘。

#### FAIL / 常见假 PASS

- `DOCTOR_OK` 但没建 trigram；
- `--download-release` 输出 `urllib.error.HTTPError` traceback；
- wizard declined exit 0；
- 只在开发者仓库能跑，release zip 缺文件；
- 缺依赖直接 `ModuleNotFoundError`。

#### 证据级别

L2：release zip 干净安装 + 失败路径；L3：另一个 Agent 复现。

---

### S2 访谈

**目标**：6 轮访谈能挖出“有日期、有代价、可追溯”的真实信息，不是骨架。

#### Must

- [v5] S2.1 固定 6 轮；每轮题目数量/顺序符合 SKILL；语言跟随用户提问语言。
- [v5] S2.2 每轮至少 1 个 dated 事件（有日期/时间范围）+ 代价/后果；总计 >=6 个 dated examples。
- [v5] S2.3 >=3 条 L4 原则（用户自己的判断标准/偏好），不是泛泛而谈。
- [补充 S2.4] S2.4 `[待确认]` 必须机器可校验形状：
  ```
  [待确认] <疑点> ｜ 原文：「…」 ｜ 出处：<file>:<line>
  ```
  - 无出处 = FAIL；
  - 无原文 = FAIL；
  - 无来源项必须删除，不得编造；
  - 出处必须能在源文件定位到。
- [补充 S2.5] S2.5 每题末位是自定义项；单选项只含单一诉求；不得把 Q1/Q3 捆绑；语言跟随提问语言。
- [补充 S2.6] S2.6 深钩实验结果标 `simulated` / `real-user`；不得把模拟写成实测。
- [v6] S2.7 “事件发生时间”与“提及时间”分开：不能把“今天想起以前的事”写成“事件发生在今天”。

#### PASS

- 6 轮完整记录；
- dated >=6，每轮 >=1；
- L4 >=3；
- `[待确认]` 形状 100% 可校验；
- 语言/选项/自定义项符合；
- simulated/real-user 标注清楚；
- 事件时间与提及时间不混。

#### FAIL / 常见假 PASS

- 模板骨架，成品 AGENTS.md 只有模板 1/4 体量；
- 13 个 dated 全堆在第 6 轮；
- `[待确认]` 没有出处/原文，或编造出处；
- 每题没有自定义项；
- 单选项里塞两个诉求；
- 把模拟回答写成“用户实测”。

#### 证据级别

L2 真实访谈记录；L4 用户确认“这确实是我说的”。

---

### S3 Kit

**目标**：6 文件 Kit 是“这个人的档案”，不是模板。

#### Must

- [v5] S3.1 6 个文件齐全；内容有具体事实/日期/案例/代价；不是占位符。
- [v5] S3.2 `03_validate_kit.py --target <kit>` 输出 `VALIDATE_OK` + exit 0。
- [补充 S3.3] S3.3 `--strict` 下 `[待确认]` 为 INFO，不 fail（SKILL rule 4 要求标注）。
- [补充 S3.4] S3.4 禁词规则：动词须紧邻引号；中文成对引号全覆盖；`--strict` 对 ASCII 占位符 `<YYYY-MM>` 也 fail。
- [补充 S3.5] S3.5 PII 基线：注入手机号/身份证/`ghp_`/`AKIA` 四类假数据全部 FAIL；正常日期/版本号/知识库路径不误杀。
- [补充 S3.6] S3.6 docs 一致性：README 轮数 = SKILL 轮数（6）；README 引用 `requirements-dev` 且 CI 同源。
- [v6] S3.7 五文件 Kit 必须 `MISSING required file` + 非零；不能静默通过。
- [v6] S3.8 合法 Kit（含正常日期/版本/路径/中文引号）不得误杀。

#### PASS

- 6 文件 + `VALIDATE_OK`；
- strict 对 `[待确认]` INFO 不 fail；
- ASCII/PII 全抓；
- 五文件/空文件 fail；
- 合法 Kit 不误杀；
- docs 轮数/依赖一致；
- 双向 fixture 进 CI。

#### FAIL / 常见假 PASS

- `VALIDATE_OK` 但 6 文件是空模板；
- strict 把 `[待确认]` 当错误；
- PII 规则只查手机号，漏 `ghp_`/`AKIA`；
- 合法日期被当 PII；
- README 写 6 轮，SKILL 写 5 轮；
- 五文件静默通过。

#### 证据级别

L2 真实 Kit + 失败 fixture；L3 独立 Agent 复现。

---

### S4 浏览器导出

**目标**：普通用户在真实浏览器里能装扩展、装脚本、看到按钮、导出文件、文件真落盘、`01` 能导入。

#### Must

- [v5] S4.1 扩展安装成功；记录官方商店/官方 release URL、版本、SHA256。
- [v5] S4.2 白色导出按钮出现；不是“页面有扩展图标”就算。
- [v5] S4.3 文件真落盘：单条 `.md` >0 字节；全部 `.zip` >0 字节；给 SHA256。
- [v5] S4.4 `01_clean_and_index.py` 能导入 >=1 条，role/time 正确。
- [补充 S4.4] S4.5 另存为系统弹窗 = `blocked-by-human`；禁止写死下载目录；必须 `Ctrl+J` 验证落盘路径。
- [补充 S4.5] S4.6 批量进度出现回退/停滞（如 331→56）标 `needs-human-confirm`，不得 PASS。
- [补充 S4.6] S4.7 单条（会话页）与全部（列表页）分别验证，各自有落盘证据。
- [补充 S4.7] S4.8 引擎（ScriptCat）+ 工人（AfterChat）都在，按钮出现才算。
- [v6] S4.9 安装 AfterChat 后必须**重载一次扩展**，再打开目标页；只 Ctrl+F5 不够。
- [v6] S4.10 导出 metadata 的 `Model` 不得重复前缀（如 `deepseek-deepseek-v4`）。
- [v6] S4.11 公开分享页 `/share/...` 不支持时，明确写 known-limit；不能当成功路径。

#### PASS

单条和全部各自：

- 官方来源安装；
- 扩展 + 脚本启用；
- 重载后按钮出现；
- 点击后文件 >0；
- `Ctrl+J` 路径/大小一致；
- SHA256；
- `01` 导入 >=1；
- 角色/时间正确；
- 模型字段不重复。

真实登录态导出：L2 + L4 用户确认。
只有 mock：L1–L2，不能写生产 PASS。

#### FAIL / 常见假 PASS

- 按钮出现但没文件；
- 截图只有按钮，没有下载记录；
- 写死 `D:/AI上下文`；
- 批量进度回退仍写 PASS；
- 单条通过就宣称全部通过；
- 扩展装了但脚本没装；
- 脚本装了但没重载，按钮不出现就写“平台不支持”；
- mock 导出写“真实平台可用”。

#### 证据级别

- 干净 Chromium + Playwright + mock：L1–L2；
- 本地真实 Edge + 真实登录：L2–L4；
- 云端 browser-use 公开页：L1；
- 真实用户点击 Save As：L4。

---

### S5 01 清洗

**目标**：把真实 AfterChat 导出清洗成可查询、角色/时间正确的索引。

#### Must

- [v5] S5.1 `INDEX_OK` + exit 0；records >0。
- [v5] S5.2 角色正确（user/assistant 不混）；时间正确（不是全 unknown）。
- [v5] S5.3 空 raw / 缺 raw 正确退出。
- [补充 S5.3] S5.4 真实 AfterChat 格式 fixture 进 CI，断言 role 分布与时间解析（真实样本曾 role 820user/1assistant、时间全 unknown）。
- [补充 S5.4] S5.5 JSONL time 键入 fixture，断言 unknown=0。
- [补充 S5.5] S5.6 `event_date` / `date_kind` 分离；假日期（2025-02-30）被真日历拒绝；月级精度不造日；祈使“记得”不误判为事件。
- [补充 S5.6] S5.7 错误专属 marker：
  - `RAW_DIR_NOT_FOUND`；
  - `NO_RECORDS` / `INDEX_EMPTY`；
  - `DB_NOT_FOUND`；
  - 每个都有可操作提示 + 非零退出。
- [v6] S5.8 非 UTF-8/坏行不能静默丢；要么跳过并计数，要么报错。

#### PASS

- `INDEX_OK`；
- DB 查询 role/time 正确；
- JSONL unknown=0；
- 假日期拒绝；
- 月级不造日；
- 祈使不误判；
- 空/缺 raw/坏行有专属 marker + 非零；
- 真实 AfterChat fixture 进 CI；
- 性能：1000 条 <=10s，10k <=60s。

#### FAIL / 常见假 PASS

- 空 raw 也 `INDEX_OK`；
- 时间全 unknown 仍 PASS；
- 角色全 user；
- 坏行静默丢；
- 假日期被接受；
- 月级写成具体日；
- 缺 DB 直接 traceback。

#### 证据级别

L2 真实导出文件；L3 独立 Agent；L4 用户确认报告可用。

---

### S6 02 四路匹配

**目标**：从索引里找出“用户说过/没说过”的候选，且可追溯。

#### Must

- [v5] S6.1 `FOUR_WAY_OK` + exit 0；报告有 Way 1 / Way 3 / Way 2&4 分节。
- [v5] S6.2 缺 DB 不 traceback，给 `FOUR_WAY_DB_NOT_FOUND` + 非零。
- [补充 S6.2] S6.3 一层只验证 told；二层（`05_deep_backfill`）反向挖 untold，两者分别验收。
- [补充 S6.3] S6.4 二层三输入（profile + 一层报告 + 冷库）+ 产物 `EXPERIMENTAL` 警示 + 签字状态机 + `needs_llm` 队列；无确认不写回正式档案。
- [v6] S6.5 空 DB 给 `FOUR_WAY_EMPTY` + 非零；2 条 mock 不得写生产 PASS。
- [v6] S6.6 每个候选可追溯到 `[REC-xxxx]`；无出处候选删除。
- [v6] S6.7 10k 条不崩溃；报告生成 <=120s。

#### PASS

- `FOUR_WAY_OK`；
- 四路分节；
- 缺/空 DB 专属错误；
- 候选可追溯；
- 一层 told / 二层 untold 分开；
- 二层有 EXPERIMENTAL + 签字 + needs_llm；
- 无确认不写回；
- 2 条 mock 只算 smoke，不算生产。

#### FAIL / 常见假 PASS

- 只有 Way 1，仍叫四路；
- 缺 DB traceback；
- 2 条 mock `FOUR_WAY_OK` 就写生产 PASS；
- 二层模型猜测直接写回正式档案；
- 候选没有 REC 出处。

#### 证据级别

L2 真实 100+ 条数据；L3 独立 Agent；L4 用户确认候选有用。

---

### S7 03 校验

**目标**：合法不误杀，非法能抓住，告警不疲劳。

#### Must

- [v5] S7.1 合法 Kit `VALIDATE_OK`；五文件/ASCII/PII 能拦。
- [补充 S7.2] S7.2 每个 commit 必须“读 diff + 复现边界输入”，不接受仅 pytest 绿的自述；作者自审与外部审查分离。
- [补充 S7.3] S7.3 告警去重/封顶；低歧义词白名单；防告警疲劳（曾 90 条）。
- [v6] S7.4 `--strict` 无 `--target` 给清晰用法 + 非零，不猜目录。
- [v6] S7.5 每条 finding 有文件:行 + 规则 ID + 修复建议。

#### PASS

- 双向 fixture；
- 合法不误杀；
- 非法全抓；
- 告警去重/封顶；
- diff + 边界输入复现记录；
- 审查非作者。

#### FAIL / 常见假 PASS

- 只看 pytest 绿；
- 90 条告警不封顶；
- 合法 Kit 被禁词误杀；
- `--strict` 无 target 猜默认目录。

#### 证据级别

L2 fixture + 真实 Kit；L3 独立审查。

---

### S8 Agent 路径

**目标**：普通用户只跟本地 AI Agent 对话，不碰终端。

#### Must

- [v5] S8.1 用户零终端：不要求用户复制命令、装 Python、改配置。
- [v5] S8.2 介入 <=3 次（登录/验证码/付费/系统弹窗单列，不占配额）。
- [v5] S8.3 raw 本地：不上传、不写仓库。
- [补充 S8.2] S8.4 介入分类计数：登录/验证码/系统弹窗/扩展授权 = `blocked-by-human`，单列；超过 3 次 => `PASS-WITH-FRICTION`。
- [v6] S8.5 每次工具调用有输入/输出/时间/exit code；失败有人话 + 恢复路径。
- [v6] S8.6 不把“用户自己看 README”当 Agent 已完成。

#### PASS

- 对话记录完整；
- 用户没有打开终端；
- 介入分类/计数；
- raw 本地；
- 失败可恢复；
- L4 用户确认“我能自己完成”。

#### FAIL / 常见假 PASS

- 让用户复制命令；
- 让用户装 Python/配环境；
- 把 5 次登录弹窗算 1 次；
- raw 上传；
- 失败只给 traceback。

#### 证据级别

L3 独立 Agent 对话；L4 用户在场。

---

### S9 PR

**目标**：每个 PR 可审查、可回退、可复现。

#### Must

- [v5] S9.1 CI 绿（Windows + Ubuntu，Python 3.11/3.12）。
- [v5] S9.2 PR 有 Evidence（before/after）、Risk、How to revert。
- [v5] S9.3 作者不自审；至少 1 名非作者 `REVIEW_PASS`。
- [补充 S9.2] S9.4 PR 声明“CI 未覆盖的真实路径”清单（如真实导出、Save As、真实登录）。
- [补充 S9.3] S9.5 一 issue 一 commit，可逐个回退；`git rev-list origin/main..HEAD` 数与 issue 数对应。
- [补充 S9.4] S9.6 确认远程 HEAD == 本地 HEAD（只读 fetch）；推不上去标 `BLOCKED`，不假装已提交。
- [v6] S9.7 高风险 PR（数据模型/迁移/权限/发布脚本/CI 密钥）必须 `DEEP_REVIEW_PASS` + 用户确认。
- [v6] S9.8 PR <=400 行 diff；超出需拆分并说明。

#### PASS

- CI 绿；
- Evidence/Risk/Revert 齐全；
- 非作者审查；
- 远程 HEAD 核对；
- 一 issue 一 commit；
- 高风险强审；
- 未覆盖路径声明。

#### FAIL / 常见假 PASS

- 作者自己 approve；
- 红 CI 合并；
- 说“已推送”但远程没有；
- 一个 PR 混多个 issue；
- 不写未覆盖路径；
- 400 行巨型 PR。

#### 证据级别

L2 CI + 本地复现；L3 独立审查；L4 用户批准高风险。

---

### S10 发布

**目标**：双平台可装、可回滚、0 P0、用户批准。

#### Must

- [v5] S10.1 Windows 11 + Ubuntu 24.04 干净环境都跑 `DOCTOR_OK` + `SMOKE_OK` + `VALIDATE_OK`。
- [v5] S10.2 release zip + SHA256 + VERSION + CHANGELOG。
- [v5] S10.3 0 P0；P1 修复或用户接受；回滚步骤可执行；用户批准。
- [补充 S10.2] S10.4 核对 CLOSED issue 的修复是否已进待发布分支，防 issue 关了代码没合。
- [补充 S10.3] S10.5 标注哪些时间能力是模拟、哪些真支持（T/T′ 重合限制）。
- [v6] S10.6 release 包不含 raw/work/profile/真实数据。
- [v6] S10.7 `known-limits.md` 写清 Save As、share URL、模拟能力、真实登录要求。
- [v6] S10.8 回滚演练：从 release 回退到上一版，数据不丢。

#### PASS

- 双平台；
- 校验和可复算；
- 0 P0；
- P1 有记录；
- CLOSED 修复在分支；
- 模拟/真支持标注；
- raw 不在包；
- known-limits；
- 回滚演练；
- 用户批准。

#### FAIL / 常见假 PASS

- 只在本机跑；
- 没校验和；
- 有 P0 仍发布；
- issue CLOSED 但代码没合；
- 把模拟时间能力写成真支持；
- 回滚没练过。

#### 证据级别

L2 双平台；L3 独立 Agent；L4 用户批准。

---

### 一句话验收表（给用户看）

| 步骤 | 一句话 PASS |
|---|---|
| S0 | 换个人按记录能复现 |
| S1 | 干净目录能装，doctor 真建表，错误是人话 |
| S2 | 6 轮能挖出有日期、有代价、可追溯的真信息 |
| S3 | 6 文件是“这个人的档案”，不是模板 |
| S4 | 真实浏览器里按钮出现，文件真落盘，01 能导入 |
| S5 | 角色/时间对，空/缺 raw 不假装成功 |
| S6 | 四路都有，候选能追到原文，二层不乱写回 |
| S7 | 合法不误杀，非法能抓住 |
| S8 | 用户不碰终端，介入次数说得清 |
| S9 | 每 PR 可审查、可回退、远程对得上 |
| S10 | 双平台能装、能回滚、0 P0、用户批准 |

---

# 03 · 提示词

## 提示词 · 并行 Agent（v6）

> 版本：v6 · 2026-11-22
> 用法：每个 Agent 只复制它对应的一段，不要把所有段都塞给它。
> 所有占位符用 `<...>` 标出，派发时替换成真实值。
> 体验 Agent 的包里**不得**出现 issue 编号、已知缺陷、预期结论、修复分支。

---

### 0. 通用上下文（所有 Agent 必读）

你是 XH-Dossier 项目的一个独立执行 Agent。项目目标：让普通用户只跟本地 AI Agent 对话，就能完成“安装 → 访谈 → 导出 → 清洗 → 校验 → 拿到可用档案”。

铁律：

- 没有标准不开工；每一步先看 `02-成功标准-v6.md` 的 Must/PASS。
- 没有证据不说 PASS；命令 exit 0 不等于结果对；截图不等于文件落盘；mock 不等于真实平台。
- 不碰 `D:\芯火剪辑系统`。
- raw 留本机；日志不含真实用户名/账号/token/手机号/身份证。
- 登录/验证码/付费/系统原生弹窗 = `blocked-by-human`，不伪造、不绕。
- 高风险操作（删除、迁移、权限、发布、CI 密钥）停“待强审”。
- 你的输出必须落到 `<RUN-DIR>`，不要只留在对话里。

---

### 1. 体验 Agent（盲测，Phase 0）

> 复制给 6 个 Workstream Owner。每个 Owner 只负责一条完整流程。
> 这段里没有任何已知 issue。

```
你是 XH-Dossier 的 Workstream Owner：<WS-ID> <WS-NAME>。
你不是只做一张票，你要从零跑完一条完整用户流程，并写出可验收的报告。

【你只能拿到】
- 任务书：<TASK-BOOK>
- 成功标准：<SUCCESS-STANDARD>
- 发布物/仓库：<RELEASE-OR-REPO>（固定 commit <COMMIT>）
- 你的 Workstream 卡：<WS-CARD>
- 输出目录：<RUN-DIR>

【禁止】
- 不读 issues/、global-plan.md、PR、fix 分支、CI 失败记录。
- 不搜索本项目 issue/PR 找答案。
- 不修改代码；你只体验、记录、提 issue。
- 不把 mock 写成真实平台；不把按钮出现写成导出成功；不把命令没报错写成 PASS。
- 不要求用户看终端、装 Python、改配置。

【环境】
- 如果你在 Windows 本地：用 PowerShell；路径 D:\...；浏览器用真实 Edge/Chrome，登录态可用。
- 如果你在 Linux 云端：用 bash；可以用 Playwright + Chromium；没有真实登录态就标 blocked-by-human。
- 如果没有浏览器：先尝试 Playwright；仍没有就写 BLOCKED，不假装。
- 扩展/用户脚本必须从官方商店或官方 release 页面通过浏览器下载；记录 URL/版本/SHA256；禁止 curl 直接拉 CRX。

【执行顺序】
S0 环境：按标准记录七项（OS/Python/Node/Git/浏览器/仓库 commit/profile 类别/扩展清单/脚本管理器/登录态/三件网络事实）。
S1 安装：从 release zip 或干净 clone 开始；跑 doctor；跑 wizard declined/consented/dry-run；跑缺依赖/403。
S2 访谈：真实跑 6 轮；每轮至少一个 dated 事件；>=6 dated；>=3 L4；[待确认] 必须有原文+出处；模拟要标 simulated。
S3 Kit：生成 6 文件；VALIDATE_OK；strict；五文件/PII/ASCII/假日期；合法样本不误杀。
S4 导出：装扩展 + 脚本；重载扩展；按钮出现；单条 .md；全部 .zip；Ctrl+J 核对落盘；01 导入；DB 查 role/time。
S5 清洗：INDEX_OK；空/缺 raw/坏 JSONL；JSONL time unknown=0。
S6 匹配：FOUR_WAY_OK；四路分节；缺/空 DB；二层三输入/EXPERIMENTAL/签字。
S7 校验：合法不误杀；非法能抓；告警去重/封顶。
S8 Agent 路径：如果你有本地 AI Agent，用对话完成；没有就写“需要什么才能测”，不假装。
收尾：写 report + issue + CONFLICT + evidence。

【每一步都要留】
- 完整命令/点击序列；
- stdout/stderr；
- exit code；
- 截图/文件路径；
- 文件 SHA256；
- DB 查询语句 + 输出；
- 证据级别 L1-L4；
- PASS / FAIL / BLOCKED / PASS-WITH-FRICTION。

【输出】
<RUN-DIR>/
  baseline.json
  experience-report.md
  issues/ISSUE-<WS>-NN.md
  conflicts/CONFLICT-NN.md
  evidence/S0...S8/
  artifacts/

【报告开头必须写】
- 我测了什么；
- 我没测到什么；
- 我最远走到哪一步；
- 我卡在哪；
- 哪些是真实数据，哪些是 mock/simulated；
- 证据级别。

【最后一句】
不要问我“要不要继续”。按标准跑完；跑不动就写 BLOCKED + 缺什么。
```

---

### 2. 工程部 Workstream Owner（Phase 3，G2 后）

> 这段只在用户批准 `global-plan.md` 后发。它包含 issue 编号和文件范围。

```
你是 XH-Dossier 工程部 Workstream Owner：<WS-ID> <WS-NAME>。
你负责把本 WS 的 issue 落成可合并的 PR，不是只写方案。

【输入】
- 冻结方案：<GLOBAL-PLAN>
- 你的 issue：<ISSUE-LIST>
- 成功标准：<SUCCESS-STANDARD>
- 仓库：<REPO>，基线 commit：<BASE-COMMIT>
- 输出目录：<RUN-DIR>

【先做】
1. 读 global-plan、成功标准、issue 验收。
2. 写 <RUN-DIR>/plan.md：技术方案、文件范围、风险、依赖。
3. 写 <RUN-DIR>/tasks.md：每张票的输入/输出/验收命令/依赖。
4. 检查 open issue/PR，已认领/CLOSED 的不重复做（H3）。
5. 确认没有 raw/真实数据会进仓库（H4）。

【再派实现子 Agent】
- 每个子 Agent 只拿一张票 + 文件范围 + 验收命令 + 失败 fixture 要求。
- 子 Agent 不得读其他 WS 的 issue/PR，避免上下文污染。
- 每个子 Agent 一分支一 PR；分支名 ws<N>/<short>-<local-id>。
- 一个 issue 一个 commit；commit 用 fix(#<id>): / feat(#<id>):。
- PR <=400 行 diff；超出拆分并说明。

【实现要求】
- TDD：先写失败 fixture，再修。
- 必跑：pytest、doctor、wizard dry-run、validate templates、空/缺 raw、缺 DB、五文件、PII、ASCII。
- 每个 PR 必带 before/after 证据、测试命令、CI run、Risk、How to revert、CI 未覆盖的真实路径。
- 不许作者自审；不许红 CI 合并；不许提交 raw/密钥/真实账号。

【输出】
<RUN-DIR>/
  plan.md
  tasks.md
  pr-list.md
  evidence/<issue>/
  merge-log.md

【最后】
给我一张表：issue -> branch -> PR -> CI -> 审查状态 -> 合并顺序 -> 回滚命令。
```

---

### 3. 实现子 Agent（单票）

```
你是 XH-Dossier 的实现子 Agent。你只做一张票，不做架构改造。

【票】
- Issue：<ISSUE-ID> <TITLE>
- 验收：<AC>
- 文件范围：<FILES>
- 基线：<BASE-COMMIT>
- 分支：<BRANCH>

【必须】
1. 先读 issue、成功标准、相关代码；写 3 行实现计划。
2. 先加失败 fixture（真实失败，不是编造），确认它失败。
3. 最小改动修到 fixture 通过。
4. 跑：pytest -q；相关脚本的成功/失败路径。
5. 读 diff，复现边界输入；不接受“pytest 绿”就交。
6. commit 一个；PR body 按模板写。
7. 不合并、不 self-approve、不碰 main。

【PR body】
### Summary
### Issue
### Evidence (before/after)
### Test commands
### CI run
### Risk
### How to revert
### CI 未覆盖的真实路径

【禁止】
- 不改无关文件；
- 不删失败 fixture；
- 不提交 raw/密钥/真实账号；
- 不把 mock 写成真实；
- 不跳过错误路径。
```

---

### 4. 独立审查 Agent（Phase 4）

> 这段是“大白话任务”，不含作者解释和预期结论。

```
你是 XH-Dossier 的独立审查 Agent。你没有参与实现，不要替作者解释。

【你拿到】
- 用户要什么：<USER-STORY>
- 这版应该做到什么：<AC>
- 成功标准：<SUCCESS-STANDARD>
- PR 列表 + diff：<PR-LIST>
- 发布物/测试环境：<ARTIFACT>
- 输出：<RUN-DIR>/review-report.md

【三条轴，分开报告，不合并】
A. Spec：PR 是否真的实现 issue 验收；有没有漏用户场景。
B. Standards：代码规范、错误处理、测试、文档一致性、跨平台。
C. Security/Data：raw/PII/密钥、路径注入、下载目录、权限、日志脱敏。

【每条 finding 必须】
- 文件:行；
- 严重度 P0/P1/P2；
- 证据：命令/输入/输出；
- 置信度；
- 建议修法；
- 是否已复现（必须实际复现边界输入，不接受“看代码觉得”）。

【结论只能】
- REVIEW_PASS：所有 Must 过，证据 >= L2；
- REVIEW_PASS_WITH_FRICTION：Must 过，Target 缺，用户可接受；
- REVIEW_FAIL：有 Must 缺 / P0；
- BLOCKED：缺环境/权限，无法判断。

【禁止】
- 不改代码；
- 不看作者“我已经修好了”的自述；
- 不把 CI 绿当 E2E；
- 不把 mock 当真实；
- 不因为“赶时间”放过 P0。
```

---

### 5. 原项目 AI 深审（Phase 4.4）

```
你是 XH-Dossier 的原项目 AI。你最了解这个项目的架构和历史决策。
你的任务不是“再看看”，而是判断这版能不能合并、能不能发布。

【输入】
- global-plan：<GLOBAL-PLAN>
- 所有 issue：<ISSUE-LIST>
- 所有 PR：<PR-LIST>
- 成功标准：<SUCCESS-STANDARD>
- 最新 main：<COMMIT>
- 输出：<RUN-DIR>/deep-review.md

【必须做】
1. 读 global-plan、issue、PR diff、CI 记录。
2. 查架构兼容、数据模型、迁移、历史决策、跨平台。
3. 在最新 main 上跑完整 E2E（按 S0-S10）。
4. 核对每个 PR 声明的“CI 未覆盖真实路径”，逐条实际跑。
5. 核对一 issue 一 commit、远程 HEAD == 本地 HEAD。
6. 高风险 PR（数据模型/迁移/权限/发布脚本/CI 密钥）给 HOLD，等用户确认。
7. 给最终结论：DEEP_REVIEW_PASS / DEEP_REVIEW_HOLD / DEEP_REVIEW_FAIL。

【输出】
- 每个 PR 的合并顺序；
- 每个 PR 的回滚命令；
- 未覆盖路径的实际结果；
- 仍然存在的 known-limits；
- 发布前必须修的 P0/P1；
- 最终结论 + 证据级别。
```

---

### 6. 盲测 Agent（用户视角）

```
你是 XH-Dossier 的盲测 Agent。你只拿发布物和用户手册，不看源码、不看作者解释、不看已知 issue。

【你拿到】
- release zip / 安装入口：<ARTIFACT>
- 用户手册：<MANUAL>
- 成功标准：<SUCCESS-STANDARD>
- 输出：<RUN-DIR>/blind-report.md

【任务】
像普通用户一样，从零完成：
1. 下载/解压；
2. 装扩展/脚本；
3. 登录（如果需要）；
4. 访谈 6 轮；
5. 生成 Kit；
6. 导出单条 + 全部；
7. 清洗 + 匹配；
8. 打开报告。

【记录】
- 每一步你点了什么、看到什么；
- 卡住时你第一时间想到什么；
- 是否需要看终端/改配置；
- 介入次数：登录/验证码/系统弹窗/扩展授权，分别计数；
- 哪些是 blocked-by-human；
- 哪些文档写了但实际做不到；
- 哪些错误提示看不懂；
- 证据级别。

【禁止】
- 不读源码；
- 不搜 issue；
- 不替作者解释；
- 不把“我猜应该这样”写成 PASS。
```

---

### 7. 发布门禁 Agent（G4）

```
你是 XH-Dossier 的发布门禁 Agent。你只做一件事：判断能不能发布。

【输入】
- release 候选：<ZIP>
- SHA256SUMS / VERSION / CHANGELOG：<FILES>
- 双平台 E2E 日志：<LOGS>
- open issue/PR：<LIST>
- 成功标准：<SUCCESS-STANDARD>
- 用户批准记录：<APPROVAL>

【逐项检查】
1. Windows 11 + Ubuntu 24.04 干净环境：DOCTOR_OK + SMOKE_OK + VALIDATE_OK。
2. zip + SHA256 + VERSION + CHANGELOG 齐全，校验和可复算。
3. 0 P0；P1 全部修复或有用户接受记录。
4. 回滚步骤可执行，数据不丢。
5. CLOSED issue 的修复在待发布分支（git log / diff 核对）。
6. release 包不含 raw/work/profile/真实数据。
7. known-limits.md 写清 Save As、share URL、模拟时间能力、真实登录要求。
8. 用户明确批准。

【结论】
- RELEASE_PASS：全部满足；
- RELEASE_HOLD：任一不满足，列缺什么、谁补、补完怎么验；
- RELEASE_FAIL：有 P0 或用户未批准。

【禁止】
- 不看“应该没问题”；
- 不跳过回滚；
- 不把 CI 绿当双平台 E2E；
- 不替用户批准。
```

---

### 8. 派发包模板（总控用）

```
【包名】XH-Dossier Phase 0 体验包 · <WS-ID>
【版本】v6 · 2026-11-22
【基线】<REPO> @ <COMMIT>
【环境】<Windows local / Linux cloud / Playwright>
【包含】
1. 01-任务书-v6.md（只摘第 5 节 + 本 WS 卡）
2. 02-成功标准-v6.md
3. 发布物/仓库
4. 输出目录模板
5. 本提示词第 1 段

【不包含】
- issue 列表
- PR / fix 分支
- global-plan
- 作者解释
- 预期结论

【回收】
- baseline.json
- experience-report.md
- issues/
- conflicts/
- evidence/
- artifacts/

【验收】
- 6 份报告齐 -> G1
- 总控汇总 -> global-plan
- 用户批准 -> G2
```

---

### 9. 一句话提醒（发给每个 Agent 的末尾）

- 你不是来“证明项目没问题”的，你是来“找出普通用户会在哪一步卡住”的。
- 先跑，再写；不要先写结论。
- 跑不动就写 BLOCKED + 缺什么，不要编。
- 任何 PASS 都要有证据级别。
- 任何“成功”都要有文件/DB/截图/exit code 四件套之一，最好四件都有。

---

# 04 · 整体方案

## 整体方案 v6（草案，未冻结）

> 状态：**G0 待批准 / G2 未冻结**。这份文件只给用户、总控、工程部看，**不得发给盲测 Agent**。
> 基线：`Dragon-01-you/xh-dossier` · 远程 `97c192b38961f498555078a1ce1613788c77041e` · 本地 `1fa699ea0b3a215b3dfd36e45f22d5b4f2afd08d`（落后 1 个 commit）
> 日期：2026-11-22

---

### 0. 先说结论

这版方案的核心不是“再写一份计划”，而是把三件事分开：

1. **体验**：6 个 Workstream Owner 在不知道已知 issue 的情况下，各自从零跑完整流程，暴露普通用户真实卡点。
2. **标准**：每一步先有 Must / PASS / 证据级别；没有证据不写 PASS。
3. **实施**：体验报告汇总成 `global-plan`，用户批准后才派实现 Agent；每个 issue 一分支一 PR，独立审查，统一合并。

当前真正卡住发布的不是“代码不够多”，而是 **S4 浏览器导出没有真实落盘证据**：

- 云端干净 Chromium 已跑通“ScriptCat + AfterChat + mock DeepSeek API → `.md` 落盘 → `01` 导入 2 条”，证据级别 L1–L2；
- 真实 DeepSeek 登录态导出未跑通，本地 Edge 环境当前离线；
- 已知 #7 的根因是 Edge `prompt_for_download=True` 弹出 Windows Save As 原生对话框，Agent/扩展点不了；这不是脚本循环。
- 所以：**不能用 mock 结果宣称生产 PASS**；S4 必须单独列 P0，直到真实文件落盘或被用户确认为 `blocked-by-human`。

---

### 1. 目标与非目标

#### 目标

- 普通用户只跟本地 AI Agent 对话，完成安装 → 访谈 → 导出 → 清洗 → 校验 → 拿到可用档案。
- 交付 release zip / 安装入口、受控工具契约、6 文件 Kit。
- 每一步有可验收标准、证据、失败画廊。
- Windows 11 + Ubuntu 24.04 双平台可装、可回滚。

#### 非目标

- 不做 GUI；
- 不绑定 Dify；
- 不把 raw 上传云端；
- 不在 `D:\芯火剪辑系统` 做任何 git/推送/实验；
- 不在 R0 支持所有平台/所有聊天工具；先 DeepSeek + 本地 Agent 路径。

---

### 2. 当前实测矩阵（截至 2026-11-22）

| 环境 | 已跑什么 | 结果 | 证据级别 | 能不能算 PASS |
|---|---|---|---|---|
| 云端 Linux + 仓库 clone | `pytest -q` | 33 passed | L1 | 只能算单测绿 |
| 云端 Linux + 机械层 | wizard declined / dry-run / 403；validate templates / strict；mock 导出 → 01 → 02 | declined exit 1；dry-run 0；403 原始 traceback；VALIDATE_OK；strict FAIL exit 1；INDEX_OK 2 条；FOUR_WAY_OK | L1–L2 | 机械层 smoke，不是生产 |
| 云端干净 Chromium + Playwright | Chrome Web Store / Edge Addons / GitHub release 下载；ScriptCat 1.5.2；AfterChat 1.25.0；mock DeepSeek | 商店不可达/按钮 disabled；GitHub release 可下；扩展+脚本装成功；重载后按钮出现；导出 374 bytes `.md`；01 导入 2 条 | L1–L2 | 浏览器链路 smoke，不是真实平台 |
| 云端真实 DeepSeek | `/share/...`、`/a/chat/s/...`、登录页 | 分享页无按钮；会话页跳登录；无登录态 | L1 | blocked-by-human |
| 本地 Windows + Edge | 真实登录态导出 | 未跑；本地环境离线；`kmenureg.exe 0xc0000142` 后掉线 | 无 | BLOCKED |
| 本地 AI Agent 对话 | 用户零终端 | 未跑 | 无 | BLOCKED |
| 盲测 | 普通用户视角 | 未跑 | 无 | BLOCKED |

#### 结论

- 机械层可以继续并行；
- S4 真实导出是 P0，必须等本地环境回来或用户明确接受 `blocked-by-human`；
- S8 盲测必须在 release 候选出来后跑；
- 现在不能发“生产级 PASS”，只能发“机械层 + 干净浏览器 smoke 已通”。

---

### 3. 问题表（现有 + 本轮新发现）

> 这张表只给总控/工程部。体验 Agent 不看。

#### 3.1 GitHub open issues

| ID | 标题 | 优先级 | Workstream | 现状 | 验收 |
|---|---|---|---|---|---|
| #1 | 访谈只产出骨架，L3/L4 信息 A/B/C 问题挖不到 | P0 | WS2 | open | 6 轮每轮至少 1 个 dated+代价；>=6 dated；>=3 L4 |
| #2 | Validator 禁词可绕过，strict 与 `[待确认]` 冲突 | P1 | WS2 | open | strict 对 `[待确认]` INFO 不 fail；禁词/ASCII 全抓 |
| #3 | 访谈 prompt 语言不跟随，Q1/Q3 捆绑 | P1 | WS2 | open | 语言跟随；单选项单一诉求；末位自定义 |
| #4 | 导出指南停在扩展，没提 AfterChat 用户脚本 | P1 | WS3 | open | 手册出现 AfterChat + 安装页 + 重载 |
| #5 | 检索只覆盖 2/4 信号，无图检索/时间检索 | P2 | WS4 | open | 四路有分节；缺的明确 known-limit |
| #6 | 二层回填只查 told，需反向挖 untold | P1 | WS4 | open | 二层三输入 + EXPERIMENTAL + 签字 + needs_llm |
| #7 | 真实导出按钮在、点了没文件；331→56 回退 | P0 | WS3 | open，根因已定位 | 单条/全部各自落盘；Save As = blocked-by-human |
| #9 | E2E problem map 10 checkpoints | P0 | WS3/WS6 | open | 10 CP 逐项有结论 |
| #10 | 事件时间 vs 提及时间，回忆事件被存成“今天发生” | P0 | WS2/WS4 | open | event_date/date_kind 分离；假日期拒绝 |
| #13 | 坏路径 dump traceback；空 raw 静默空库 | P1 | WS1/WS3/WS4 | open | 专属 marker + 非零；空 raw 不静默 |
| #15 | `[待确认]` 不可追溯，有一条编造 | P0 | WS2 | open | 形状可校验；无出处/原文 FAIL |

#### 3.2 本轮云端新发现

| ID | 现象 | 优先级 | Workstream | 证据 | 建议 |
|---|---|---|---|---|---|
| C1 | Chrome Web Store 不可达；Edge Addons 在 Chromium 里 `获取` disabled | P1 | WS3 | `extensions-page.png`、商店日志 | 记录环境限制；官方 GitHub release 作为 fallback；不冒充商店通过 |
| C2 | 安装 AfterChat 后不重载扩展，按钮不注入；只 Ctrl+F5 不够 | P0 | WS3 | `mock-deepseek-button.png` vs `mock-after-reload.png` | 文档加“重载扩展一次”；安装向导加检查 |
| C3 | DeepSeek `/share/...` 分享页不注入按钮；adapter 只认 `/a/chat/s/<id>` | P1 | WS3 | `share-after-reload.log` | R0 写 known-limit；后续 issue 支持 share |
| C4 | 导出 metadata `Model: deepseek-deepseek-v4` 重复前缀 | P1 | WS3 | `Mock Conversation.md` | 修 adapter 或本地包装；加 fixture |
| C5 | `00_export_wizard --download-release` 403 输出原始 traceback | P1 | WS1 | `wizard-download-release.log` | `RELEASE_FETCH_FAILED` + exit 2 |
| C6 | 2 条 mock 记录也输出 `FOUR_WAY_OK`，容易被当生产 PASS | P1 | WS4 | `pipeline-fourway.log` | 加“样本量不足”警告；生产 PASS 需 >=100 条真实 |
| C7 | 浏览器证据只有 mock，没有真实登录态落盘 | P0 | WS3/WS6 | 证据目录 | 本地 Edge 真实导出；否则 BLOCKED |
| C8 | 本地 Edge 掉线，真实导出/盲测无法跑 | P0 阻塞 | WS3/WS6 | baseline | 等用户本地重新上线；不假装 |
| C9 | 批量导出 Save As 原生弹窗无法点 | P0 | WS3 | #7 评论 | 归入 #7；文档 + `blocked-by-human` 分类 |
| C10 | 官方 GitHub release 可下，但“商店路径”未验证 | P1 | WS3 | release zip hash | 记录两条路径，不合并结论 |

#### 3.3 已关闭但需要回归的

#8 / #11 / #17 / #19 / #21 / #23 / #28 已 CLOSED。实施阶段每个 PR 必须确认这些修复没有被回归；发布门禁核对“CLOSED 的修复是否进待发布分支”。

---

### 4. 6 个 Workstream

| WS | 名称 | 主范围 | 主要 issue | 关键产出 |
|---|---|---|---|---|
| WS1 | 安装 / doctor / Agent 契约 | release zip、doctor、wizard、依赖、错误文案、Agent 入口 | #13（错误路径）、C5 | 干净安装、doctor、wizard、契约 |
| WS2 | 访谈 / Kit / 校验 | 6 轮、6 文件、validate、`[待确认]`、PII/ASCII | #1 #2 #3 #10 #15 | 访谈记录、Kit、validate、fixtures |
| WS3 | 浏览器导出 / 导入清洗 | 扩展、AfterChat、单条/全部、下载、01、真实格式 | #4 #7 #9 C1–C4 C7–C10 | 扩展清单、落盘文件、DB、fixtures |
| WS4 | 四路匹配 / 二层回填 | 02 四路、缺/空 DB、05 回填、needs_llm | #5 #6 #10 #13 C6 | 报告、候选、签字状态、fixtures |
| WS5 | CI / 安全 / 发布 | CI 矩阵、secret/PII、隔离、release、校验和、回滚 | #13（门禁）、H2/H4 | CI、扫描报告、release、rollback |
| WS6 | 文档 / 示例 / 盲测 | 手册、known-limits、示例、盲测 | #4 #9 C3 C7 | 手册、盲测报告、文档 issue |

#### 边界

- WS3 拥有“浏览器怎么点、文件怎么落、Save As 怎么处理”；WS1 只拥有“CLI 怎么包装、错误怎么打”。
- WS2 拥有 `[待确认]` 规则和 validator 的单一事实源；WS5 只加 secret scan，不重复实现 PII 规则。
- WS1 拥有安装章节；WS6 拥有其余文档；同一段不两人写。
- WS4 消费 WS3 的 `records` schema；schema 在 `interface-contract.md` 冻结，改 schema 走 CONFLICT。

---

### 5. 工具契约（建议冻结）

#### 5.1 CLI

| 命令 | 作用 | 成功 | 失败 |
|---|---|---|---|
| `00_doctor.py` | 环境自检 | `DOCTOR_OK` exit 0 | `DOCTOR_FAIL` exit 2 |
| `00_export_wizard.py` | 导出向导 | consented exit 0 | `WIZARD_DECLINED` 非零；`RELEASE_FETCH_FAILED` exit 2 |
| `01_clean_and_index.py` | 清洗索引 | `INDEX_OK` exit 0 | `RAW_DIR_NOT_FOUND` / `INDEX_EMPTY` / `DB_NOT_FOUND` 非零 |
| `02_four_way_match.py` | 四路匹配 | `FOUR_WAY_OK` exit 0 | `FOUR_WAY_DB_NOT_FOUND` / `FOUR_WAY_EMPTY` 非零 |
| `03_validate_kit.py` | Kit 校验 | `VALIDATE_OK` exit 0 | `VALIDATE_FAIL` exit 1 |
| `05_deep_backfill.py` | 二层回填 | `BACKFILL_OK` exit 0 | `BACKFILL_EXPERIMENTAL` 非零？需定 |
| `06_package_release.py` | 打包发布 | `RELEASE_OK` exit 0 | `RELEASE_FAIL` 非零 |

#### 5.2 退出码语义

| 码 | 含义 |
|---|---|
| 0 | 成功 |
| 1 | 校验失败（输入不合法） |
| 2 | 输入/环境错误（缺文件、缺依赖、网络） |
| 3 | 用户拒绝/门禁未通过 |
| 4 | `blocked-by-human`（登录/验证码/系统弹窗） |
| 5 | 高风险，待强审 |

#### 5.3 文件布局

```
work/
  raw/                 # 用户本机，不进仓库
  kit/                 # 6 文件
  index.db             # 不进仓库
  reports/
    four_way_match.md
    backfill_candidates.md
  evidence/            # 脱敏后可进仓库
```

#### 5.4 Agent 工具入参/出参（概念）

| 工具 | 入参 | 出参 |
|---|---|---|
| `doctor` | 无 | `{ok, checks[], errors[]}` |
| `interview.start` | `{language, profile?}` | `{session_id, question}` |
| `interview.answer` | `{session_id, answer}` | `{next_question, round, done}` |
| `interview.finish` | `{session_id}` | `{kit_path, pending[]}` |
| `export.guide` | `{platform, browser}` | `{steps[], blocked_by_human[]}` |
| `export.verify` | `{path}` | `{exists, size, sha256, importable}` |
| `clean.index` | `{raw_dir, db_path}` | `{records, roles, dates, errors}` |
| `match.four_way` | `{db_path, out_dir}` | `{report_path, candidates, warnings}` |
| `validate.kit` | `{kit_dir, strict}` | `{ok, findings[]}` |
| `deliver.package` | `{version, out_dir}` | `{zip, sha256, manifest}` |

契约冻结后，WS1 实现入口，WS3/WS4 只按契约调用；改契约走 CONFLICT。

---

### 6. 浏览器 E2E 方案（S4 重点）

#### 6.1 三条轨道

| 轨道 | 环境 | 目的 | 证据 |
|---|---|---|---|
| A 干净 Chromium + Playwright | 云端/本地 | 证明“从零安装扩展/脚本 + 注入 + 下载”可跑 | L1–L2 |
| B 本地真实 Edge（脏 profile） | 本地 Windows | 证明“真实登录 + 真实平台 + 真实下载”可跑 | L2–L4 |
| C 云端 browser-use | 云端 | 证明公开页/官方 release 可达；不冒充用户本机 | L1 |

#### 6.2 Track A 步骤

1. 下载官方 ScriptCat release zip（浏览器下载，记录 URL/版本/SHA256）。
2. 解压到 `ext/scriptcat`。
3. `launch_persistent_context` + `--disable-extensions-except` + `--load-extension`。
4. 打开 `chrome://extensions`，开 developer mode。
5. 打开详情，开 `Allow User Scripts`；如扩展变 Off，重新启用。
6. 用本地 HTTP server 提供 `afterchat.user.js`；打开 `chrome-extension://.../src/install.html?url=...`。
7. 点主按钮 `Install Script`，确认安装完成页。
8. 打开 ScriptCat 仪表盘，确认 AfterChat v1.25.0 启用。
9. **重载扩展**（developerPrivate.reload）。
10. 打开 mock `/a/chat/s/test-id`，拦截 `history_messages` 返回构造 JSON。
11. 断言 `#m365-export-container` 存在；截图按钮。
12. 点击导出，等 download 事件；保存 `.md`；断言 >0 字节。
13. 用 `01_clean_and_index.py` 导入；查 DB role/time。
14. 断言 metadata model 不重复。

#### 6.3 Track B 步骤

1. 用真实 Edge/Chrome，真实 profile，真实登录。
2. 从官方商店/官方 release 安装 ScriptCat + AfterChat。
3. 重载扩展；打开真实 DeepSeek `/a/chat/s/<id>`。
4. 单条导出：点按钮；如弹 Save As，用户点保存；`Ctrl+J` 核对路径/大小。
5. 全部导出：列表页点全部；如进度回退/停滞，标 `needs-human-confirm`；如弹 Save As，标 `blocked-by-human`。
6. 文件落盘后给 SHA256；`01` 导入；DB 查 role/time。
7. 记录真实账号名脱敏、浏览器版本、扩展版本、下载目录。

#### 6.4 Track C 步骤

1. 云端 browser-use 打开官方 release/商店页。
2. 记录可达/不可达、按钮状态、下载是否成功。
3. 不登录真实账号；不冒充 Track B。

#### 6.5 S4 PASS 判定

- Track A 通过 = L2 smoke，不等于生产。
- Track B 通过 = L2–L4，才算 S4 生产 PASS。
- Track B 无法跑 = `BLOCKED`；不能用 Track A 替代。
- Save As 弹窗 = `blocked-by-human`；批量进度回退 = `needs-human-confirm`；两者都不算 PASS。

---

### 7. PR 拆分与合并顺序

#### 7.1 分支/PR

| WS | PR | 内容 | 依赖 | 回滚 |
|---|---|---|---|---|
| WS1 | 1 | release zip + doctor 真建表 | — | 删 release 脚本 |
| WS1 | 2 | wizard declined/consented + 403 人话 | PR1 | 恢复 wizard |
| WS1 | 3 | Agent 入口/契约 + 错误码 | PR2 | 删入口 |
| WS1 | 4 | S1 失败 fixtures | PR2/3 | 删 fixtures |
| WS2 | 1 | 访谈 6 轮 prompt + 语言/选项 | — | 恢复 prompt |
| WS2 | 2 | `[待确认]` 形状 + 追溯 | PR1 | 恢复规则 |
| WS2 | 3 | validator strict/PII/ASCII/禁词 | PR2 | 恢复 validator |
| WS2 | 4 | docs 轮数/依赖一致 | PR3 | 恢复 docs |
| WS3 | 1 | 浏览器手册 + 重载扩展 | — | 恢复手册 |
| WS3 | 2 | export.verify + 下载检测 | PR1 | 删 verify |
| WS3 | 3 | AfterChat adapter model/share | PR1 | 恢复 adapter |
| WS3 | 4 | 01 真实格式 parser + JSONL time | PR1 | 恢复 parser |
| WS3 | 5 | S4 失败 fixtures | PR2/3/4 | 删 fixtures |
| WS4 | 1 | 02 缺/空 DB 错误 | — | 恢复 02 |
| WS4 | 2 | 四路分节 + 候选追溯 | PR1 | 恢复 02 |
| WS4 | 3 | 05 二层三输入/EXPERIMENTAL/签字 | PR1/2 | 恢复 05 |
| WS4 | 4 | S6 fixtures | PR2/3 | 删 fixtures |
| WS5 | 1 | CI 矩阵 Win/Ubuntu Py3.11/3.12 | — | 恢复 CI |
| WS5 | 2 | secret/PII/数据隔离 | PR1 | 恢复扫描 |
| WS5 | 3 | release zip/checksum/rollback | PR1 | 恢复发布脚本 |
| WS5 | 4 | E2E 脚本双平台 | PR3 | 删 E2E |
| WS6 | 1 | 用户手册 + known-limits | — | 恢复手册 |
| WS6 | 2 | 示例 + 盲测脚本 | PR1 | 删示例 |
| WS6 | 3 | 盲测报告 + 文档修复 | PR2 | 恢复文档 |

#### 7.2 合并顺序

1. WS1-1/2/3/4；
2. WS2-1/2/3/4；
3. WS3-1/2/3/4/5；
4. WS4-1/2/3/4；
5. WS5-1/2/3/4；
6. WS6-1/2/3。

每合一个 PR：rebase 最新 main → CI → E2E → merge commit → 记录。失败 revert 该 PR，不阻塞其他。

---

### 8. CONFLICT 登记（预判）

| ID | 冲突 | 双方 | 建议裁决 | 状态 |
|---|---|---|---|---|
| C-01 | 下载路径/ Save As 归谁 | WS1 vs WS3 | WS3 拥有浏览器行为；WS1 只包装 CLI，不承诺自动点原生弹窗 | 待 G2 批准 |
| C-02 | `records` schema 改动 | WS3 vs WS4 | 冻结 `rec_id/source_file/created_at/role/content/md5`；改 schema 走 CONFLICT | 待批准 |
| C-03 | PII 规则重复 | WS2 vs WS5 | `03_validate_kit.py` 是唯一事实源；WS5 只加 secret scan | 待批准 |
| C-04 | 安装文档重复 | WS1 vs WS6 | WS1 写安装章节；WS6 引用，不重写 | 待批准 |
| C-05 | CI 浏览器测试 | WS5 vs WS3 | CI 只跑 Track A mock；Track B 真实路径由 WS3 在 PR 声明“未覆盖” | 待批准 |
| C-06 | 事件时间 vs 提及时间 | WS2 vs WS4 | WS2 在访谈记录里分离；WS4 在索引/匹配里不合并 | 待批准 |

---

### 9. 失败画廊（把真实失败变成回归）

最低要加：

- S1 `release-403`：`RELEASE_FETCH_FAILED` + exit 2；
- S1 `wizard-declined`：exit 3 + marker；
- S2 `interview-skeleton`：轮数/dated/L4 不足；
- S2 `pending-un traceable`：无出处/原文；
- S3 `kit-five-files`：`MISSING required file`；
- S3 `kit-pii`：手机号/身份证/ghp_/AKIA；
- S3 `kit-ascii`：strict fail；
- S4 `afterchat-no-reload`：按钮不出现；
- S4 `save-as-dialog`：blocked-by-human；
- S4 `batch-progress-reset`：needs-human-confirm；
- S5 `empty-raw`：`INDEX_EMPTY`；
- S5 `jsonl-time-missing`：unknown=0 失败；
- S6 `missing-db`：`FOUR_WAY_DB_NOT_FOUND`；
- S6 `mock-2-records`：不得生产 PASS；
- S9 `self-approve`：审查拒绝；
- S10 `closed-not-merged`：发布门禁拒绝。

每个 fixture 进 CI，修完不删。

---

### 10. CI 矩阵

| Job | OS | Python | 内容 |
|---|---|---|---|
| unit | Ubuntu 24.04 | 3.11/3.12 | pytest |
| unit-win | Windows 11 | 3.11/3.12 | pytest |
| doctor | 双平台 | 3.12 | doctor + FTS5/trigram |
| failure-paths | 双平台 | 3.12 | 空 raw/缺 DB/五文件/PII/ASCII/wizard |
| browser-smoke | Ubuntu | 3.12 | Chromium + ScriptCat + AfterChat + mock route；按钮 + 下载 + 01 导入 |
| secret-scan | Ubuntu | — | gitleaks/trufflehog 或 regex |
| data-isolation | Ubuntu | — | `git ls-files` 不含 raw/work/*.db/真实访谈 |
| release | Ubuntu | 3.12 | zip + sha256 + rollback 脚本检查 |

真实登录、真实平台、Save As 不在 CI；PR 必须声明。

---

### 11. 发布与回滚

#### 发布物

- `xh-dossier-<version>.zip`
- `SHA256SUMS`
- `VERSION`
- `CHANGELOG.md`
- `known-limits.md`
- `rollback.md`
- 用户手册

#### 回滚

- 保留上一版 zip；
- `rollback.md` 写：停用新版本 → 解压旧版 → 恢复 `work/` 数据 → `doctor`；
- 回滚不删用户 `raw/`；
- 回滚演练一次，记录时间/结果。

#### 发布门禁

- Windows 11 + Ubuntu 24.04；
- 0 P0；P1 修复或用户接受；
- CLOSED issue 修复在分支；
- 校验和可复算；
- 用户批准。

---

### 12. 风险

| 风险 | 影响 | 应对 |
|---|---|---|
| 本地 Edge 继续离线 | S4/S8 无法生产 PASS | 用户重新上线；否则 G4 不通过 |
| Save As 原生弹窗无法自动点 | 用户以为导出失败 | 文档 + `blocked-by-human` 分类；`Ctrl+J` 检查 |
| 商店不可达 | 安装路径不通 | 官方 release fallback；记录环境限制 |
| share URL 不支持 | 用户分享链接打不开 | known-limits；后续 issue |
| mock 被当真实 | 发布假 PASS | 证据分级；S4 必须 Track B |
| 6 个 Agent 上下文污染 | 重复 issue/冲突 | 体验包不含已知 issue；H3 并发避让 |
| 一 issue 多 commit | 无法回退 | S9 门禁；rev-list 核对 |
| raw/PII 进仓库 | 隐私事故 | H4 门禁 + secret scan |

---

### 13. 需要用户拍板的 6 件事（G0/G2）

1. **Save As 算不算可接受摩擦？** 建议：算 `blocked-by-human`，不算失败；用户自己点保存。若不同意，需要改 AfterChat/浏览器策略。
2. **share URL 是否 R0 支持？** 建议：R0 写 known-limit，不阻塞发布；后续 issue。
3. **模型字段重复前缀修在哪？** 建议：优先给 AfterChat 上游提 issue；本地包装层加兼容；R0 不阻塞。
4. **本地 Edge 什么时候能上线？** 没有它，S4/S8 只能 BLOCKED，G4 不能过。
5. **时间能力哪些是模拟、哪些真支持？** 需要写进 `known-limits.md`；建议只承诺“有日期的事件”，不承诺“精确到分钟”。
6. **是否接受 `PASS-WITH-FRICTION`？** 建议接受：Must 全过、Target 缺、用户知情；但不接受 P0 带病发布。

---

### 14. 冻结检查清单（G2）

- [ ] 6 份体验报告齐；
- [ ] 每个 PASS 有证据级别；
- [ ] 每个 FAIL 有 issue + fixture；
- [ ] 每个 CONFLICT 有裁决；
- [ ] issue 表 P0/P1/P2 + owner + 依赖；
- [ ] PR 拆分 <=400 行；
- [ ] CI 矩阵含双平台 + browser-smoke；
- [ ] 失败画廊清单；
- [ ] 数据隔离门禁；
- [ ] 回滚演练；
- [ ] 用户批准日期/签名。

---

### 15. 下一步

1. 用户看这份 + `02-成功标准-v6.md` + `03-提示词-v6.md`；
2. 用户回答第 13 节 6 个问题；
3. G0 通过后，总控发 6 个体验包；
4. 体验报告回来，总控写冻结版 `global-plan`；
5. G2 通过后，才派实现 Agent。

---

# 05 · 实测记录

## 实测记录 · 2026-11-22（云端干净 Chromium + 机械层）

> 这份记录只写“实际跑了什么、看到什么、能证明什么”。不写“应该没问题”。
> 环境：云端 Linux（`vm`）· Chromium 146.0.7680.31 · Python 3.12.11 · Playwright persistent context · 代理可用（GitHub 可达，Google/Chrome Web Store 不可达）
> 仓库：`/home/user/xh-runs/main-20261122/xh-dossier` @ `97c192b38961f498555078a1ce1613788c77041e`

---

### 0. 结论先行

已跑通：

- 机械层：`pytest` 33 passed；wizard declined/dry-run；validate templates / strict；mock 导出 → `01` → `02`。
- 干净浏览器：官方 GitHub release 下载 ScriptCat 1.5.2；装 AfterChat 1.25.0；重载扩展后按钮出现；点击真实下载 `Mock Conversation.md` 374 bytes；`01` 导入 2 条；role/time 正确；`02` `FOUR_WAY_OK`。

没跑通：

- 真实 DeepSeek 登录态导出（无登录态，`blocked-by-human`）；
- 真实 Edge 本机导出（本地环境离线）；
- 真实 Save As 原生弹窗处理（未到那一步）；
- 批量全部导出（未到那一步）；
- 用户零终端 Agent 路径（未跑）；
- 盲测（未跑）。

因此：**当前最多 L1–L2 smoke，不是生产级 PASS。**

---

### 1. 环境 baseline

| 项 | 值 |
|---|---|
| OS | Linux（云端 vm） |
| Python | 3.12.11 |
| Chromium | 146.0.7680.31（`/usr/local/bin/chromium`） |
| Playwright | persistent context（版本未单独打印） |
| 代理 | `HTTPS_PROXY` 可用；GitHub 可达；Chrome Web Store 不可达 |
| 仓库 | `https://github.com/Dragon-01-you/xh-dossier` |
| commit | `97c192b38961f498555078a1ce1613788c77041e`（fix #28） |
| 本地仓库 | `1fa699ea0b3a215b3dfd36e45f22d5b4f2afd08d`（落后 1 commit，32 passed） |
| profile | `profile-clean`（干净，无登录态；装 ScriptCat + AfterChat） |
| 扩展 | ScriptCat `adoaajilakgjdhgfagodfoaoldhffaid` v1.5.2，ENABLED，userScriptsAccess active |
| 脚本 | AfterChat v1.25.0，启用 |

---

### 2. 机械层

#### 2.1 pytest

命令：

```bash
cd /home/user/xh-runs/main-20261122/xh-dossier
python3 -m pytest -q
```

输出：`33 passed in 0.34s`。

证据：`evidence/pytest-cloud.log`。

#### 2.2 wizard

| 命令 | 结果 | 证据 |
|---|---|---|
| `python3 00_export_wizard.py`（无输入） | `WIZARD_DECLINED`，exit 1 | `evidence/wizard-declined.log` |
| `python3 00_export_wizard.py --yes --dry-run` | exit 0 | `evidence/wizard-dryrun.log` |
| `python3 00_export_wizard.py --download-release --yes` | GitHub API 403，原始 traceback，exit 1 | `evidence/wizard-download-release.log` |

#### 2.3 validate

| 命令 | 结果 | 证据 |
|---|---|---|
| `python3 03_validate_kit.py --target templates` | `VALIDATE_OK` | `evidence/validate-templates.log` |
| `python3 03_validate_kit.py --target templates --strict` | `VALIDATE_FAIL`，exit 1，抓 ASCII 占位符 | `evidence/validate-templates-strict.log` / `validate-strict2.log` |

#### 2.4 清洗 + 匹配（mock 导出）

命令：

```bash
python3 01_clean_and_index.py --raw pipeline/raw --db pipeline/work/unified_index.db
python3 02_four_way_match.py --db pipeline/work/unified_index.db --out pipeline/work/backfill_candidates.md
```

输出：

```text
INDEX_OK total_raw=2 dedup_skipped=0 indexed=2
QUERY '你好' -> 0 hit(s)
FOUR_WAY_OK records=2 clusters=1 out=.../backfill_candidates.md
```

DB：

| rec_id | source_file | created_at | role | content |
|---|---|---|---|---|
| REC-0001 | Mock Conversation.md | 2025-10-09 | user | Hello, this is a mock user message. |
| REC-0002 | Mock Conversation.md | 2025-10-09 | assistant | #### 🤔 Thought Process ... |

证据：`evidence/pipeline-clean.log`、`evidence/pipeline-fourway.log`、`pipeline/work/unified_index.db`。

注意：2 条 mock 的 `FOUR_WAY_OK` 只能算 smoke，不能算生产 PASS（见 CLOUD-06）。

---

### 3. 浏览器层（干净 Chromium + Playwright）

#### 3.1 商店路径

| 目标 | 结果 |
|---|---|
| Chrome Web Store `https://chromewebstore.google.com/detail/hompjdfbfoggjbeebconmlijpelpfapo` | 页面报“检查代理服务器和防火墙”，不可达 |
| Edge Addons `https://microsoftedge.microsoft.com/addons/detail/liilgpjgabokdklappibcjfablkpcekh` | 页面能加载，但 Chromium 中“获取”按钮 disabled |
| GitHub release `https://github.com/scriptscat/scriptcat/releases/tag/v1.5.2` | 可下载 `scriptcat-v1.5.2-chrome.zip`，5,323,521 bytes |

证据：`evidence/extensions-page.png`、`evidence/proxy-test.png`、`evidence/scriptcat-details.png`、`ext/scriptcat-v1.5.2-chrome.zip`。

#### 3.2 扩展安装

1. 解压 release 到 `ext/scriptcat`。
2. Playwright persistent context + `--disable-extensions-except` + `--load-extension` 加载。
3. `chrome://extensions` 显示 ScriptCat 1.5.2，ENABLED。
4. 详情页 `Allow User Scripts` 默认关闭；开启后，扩展曾变 Off，重新启用。
5. `userScriptsAccess.isActive=true`，`manifestErrors=[]`，`runtimeErrors=[]`。

证据：`evidence/scriptcat-details-final.png`、`evidence/ext-full.json`、`evidence/ext-errors.log`。

#### 3.3 AfterChat 安装

- GreasyFork 页面在云端不可达；改用官方 GitHub 源码：
  `https://github.com/AfterThink/AfterChat-Script`
- 本地 HTTP server 提供 `afterchat.user.js`：
  `http://127.0.0.1:8765/afterchat.user.js`
- 直接导航 `.user.js` 会触发下载，不会自动进 ScriptCat 安装页；必须打开：
  `chrome-extension://adoaajilakgjdhgfagodfoaoldhffaid/src/install.html?url=http://127.0.0.1:8765/afterchat.user.js`
- 安装页显示 v1.25.0；点主按钮 `Install Script`（不是右侧下拉箭头）后安装成功。

证据：`evidence/afterchat-install-page2.png`、`evidence/afterchat-installed-result.png`、`evidence/scriptcat-options.png`。

#### 3.4 注入 / 按钮

| 场景 | 结果 |
|---|---|
| 安装后直接打开 mock `/a/chat/s/test-id` | `m365-export-container=false`，白页无按钮 |
| 执行 `chrome.developerPrivate.reload(...)` 后打开同一页 | `m365-export-container=true`，按钮 rect `{x:1224,y:844,w:36,h:36}` |
| 点击按钮 | 真实下载 `Mock Conversation.md` 374 bytes |

证据：`evidence/mock-deepseek-button.png`（未重载，无按钮）、`evidence/mock-after-reload.png`（重载后有按钮）、`evidence/afterchat-button.png`（按钮元素）、`evidence/mock-export-evidence2.log`（`container True` + `DOWNLOAD ... 374`）。

#### 3.5 导出文件内容

```md
### Metadata

- **Model:** `deepseek-deepseek-v4`
- **Time:** 2025-10-09 16:53:20 +08:00
- **URL:** https://chat.deepseek.com/a/chat/s/test-id

### Conversation

#### 🧑‍💻 User

Hello, this is a mock user message.

#### 🤖 Assistant

#### 🤔 Thought Process

The user says hello. I should reply briefly.

#### 💡 Response

Hi there! This is a mock assistant reply.
```

发现：`Model` 重复前缀（CLOUD-04）。

#### 3.6 真实 DeepSeek

| 页面 | 结果 |
|---|---|
| `https://chat.deepseek.com/share/horj9tlug5klc6q8oj` | 页面正常显示 Shared Conversation；`m365-export-container=false`；无按钮 |
| `https://chat.deepseek.com/a/chat/s/test-id`（未登录） | 跳登录页；无按钮 |
| `https://chat.deepseek.com/sign_in` | 要求手机验证码/密码/微信扫码；无登录态 |

证据：`evidence/deepseek-share-afterchat.png`、`evidence/deepseek-signin-afterchat.png`、`evidence/share-after-reload.log`。

结论：真实登录态导出 `blocked-by-human`；不能用 mock 冒充。

---

### 4. 失败画廊候选

| 失败 | 证据 | 期望 fixture |
|---|---|---|
| 商店不可达 | `proxy-test.png` | `store-unreachable`：记录 + fallback |
| 不重载扩展无按钮 | `mock-deepseek-button.png` | `afterchat-no-reload`：按钮不存在 |
| 重载后有按钮 | `mock-after-reload.png` | `afterchat-reload`：按钮存在 |
| 分享页无按钮 | `share-after-reload.log` | `share-url`：known-limit |
| model 重复 | `Mock Conversation.md` | `model-prefix`：断言不重复 |
| wizard 403 traceback | `wizard-download-release.log` | `release-403`：人话 + exit 2 |
| 2 条 mock `FOUR_WAY_OK` | `pipeline-fourway.log` | `low-sample`：警告，不生产 PASS |
| 真实登录缺失 | `deepseek-signin-afterchat.png` | `blocked-by-human`：不计 FAIL |

---

### 5. 不能从这份记录得出的结论

- 不能说“普通用户已经能完成导出”：没有真实登录态、没有真实 Save As、没有批量导出。
- 不能说“Windows 可用”：没有在 Windows 11 上跑。
- 不能说“Agent 路径可用”：没有本地 AI Agent 对话记录。
- 不能说“商店路径可用”：Chrome Web Store 不可达，Edge Addons 按钮 disabled。
- 不能说“四路匹配有效”：只有 2 条 mock，候选为空。
- 不能说“发布级 PASS”：证据级别最多 L1–L2，没有 L3/L4。

---

### 6. 证据索引

| 文件 | 内容 |
|---|---|
| `evidence/pytest-cloud.log` | 33 passed |
| `evidence/wizard-declined.log` | WIZARD_DECLINED exit 1 |
| `evidence/wizard-dryrun.log` | dry-run exit 0 |
| `evidence/wizard-download-release.log` | 403 traceback |
| `evidence/validate-templates.log` | VALIDATE_OK |
| `evidence/validate-templates-strict.log` | VALIDATE_FAIL exit 1 |
| `evidence/pipeline-clean.log` | INDEX_OK 2 |
| `evidence/pipeline-fourway.log` | FOUR_WAY_OK 2 |
| `evidence/ext-full.json` | ScriptCat 1.5.2，userScriptsAccess active |
| `evidence/scriptcat-details-final.png` | 开发者模式 + On |
| `evidence/scriptcat-options.png` | AfterChat 1.25.0 启用 |
| `evidence/afterchat-install-page2.png` | 安装页 v1.25.0 |
| `evidence/afterchat-installed-result.png` | 安装完成页 |
| `evidence/mock-deepseek-button.png` | 未重载，无按钮 |
| `evidence/mock-after-reload.png` | 重载后按钮 |
| `evidence/afterchat-button.png` | 按钮元素 |
| `evidence/mock-export-evidence2.log` | 下载 374 bytes |
| `evidence/Mock Conversation.md` | 导出文件 |
| `evidence/deepseek-share-afterchat.png` | 分享页无按钮 |
| `evidence/deepseek-signin-afterchat.png` | 登录页 |
| `evidence/share-after-reload.log` | 分享页 container False |

---

# 06 · 模板

## 模板 · 体验报告 / issue / CONFLICT（v6）

> 每个 Agent 复制对应模板填写，不要自由发挥格式。

---

### 1. 体验报告模板

```md
## 体验报告 · <WS-ID> <WS-NAME>

- Agent：<AGENT-ID>
- 日期：<YYYY-MM-DD>
- 环境：<OS / 浏览器 / Python / 仓库 commit>
- 证据级别上限：L1 / L2 / L3 / L4
- 我最远走到：S<N>
- 结论：PASS / PASS-WITH-FRICTION / FAIL / BLOCKED

### 0. 我测了什么（3 行）

### 1. 我没测到什么（3 行）

### 2. 逐步结果

| 步骤 | 结果 | 证据级别 | 关键证据 | 备注 |
|---|---|---|---|---|
| S0 | PASS/FAIL/BLOCKED | L1-L4 | `evidence/S0/...` | |
| S1 | | | | |
| ... | | | | |

### 3. 卡点清单

| # | 卡在哪 | 现象 | 我第一时间以为 | 实际原因 | 证据 |
|---|---|---|---|---|---|
| 1 | | | | | |

### 4. 真实 vs 模拟

| 数据/环节 | real-user / simulated / mock | 说明 |
|---|---|---|
| | | |

### 5. 介入计数

| 类型 | 次数 | 是否 blocked-by-human |
|---|---|---|
| 登录 | | |
| 验证码 | | |
| 系统弹窗 | | |
| 扩展授权 | | |
| 其他 | | |

### 6. 我认为的 P0/P1/P2

| 优先级 | 问题 | 为什么 |
|---|---|---|
| P0 | | |

### 7. 附：证据索引

| 文件 | 内容 | SHA256 |
|---|---|---|
| | | |
```

---

### 2. issue 模板

```md
## <LOCAL-ID> · <现象标题>

- 步骤：S<N>
- 环境：<OS / 浏览器 / 扩展版本 / profile 类别 / commit>
- 证据级别：L1 / L2 / L3 / L4
- 影响：P0 / P1 / P2

### 现象

<最少复现步骤 + 实际看到什么>

### 期望

<按成功标准，应该怎样>

### 实际

<实际输出/截图/文件大小/DB 查询>

### 证据

- `evidence/...`：<说明>
- 命令：`<command>`
- exit code：<n>
- 文件 SHA256：<hash>
- DB 查询：`<sql>` -> <输出>

### 验收

- [ ] <命令/点击> 得到 <期望>
- [ ] 失败 fixture：<name>
- [ ] 独立 Agent 复现：<who/where>

### 不做

- <明确不修的范围>
```

---

### 3. CONFLICT 模板

```md
## CONFLICT-<NN> · <一句话>

- 双方：<WS-A> vs <WS-B>
- 冲突点：<文件/接口/数据格式/文档口径>
- 发现时间：<YYYY-MM-DD>
- 阻塞什么：<哪张票/哪个 PR>

### A 方案

<做法、代价、风险>

### B 方案

<做法、代价、风险>

### 建议裁决

<总控建议 + 理由>

### 等谁拍板

- [ ] 总控
- [ ] 用户
- [ ] 原项目 AI

### 裁决记录

<日期 / 结论 / 谁拍的>
```

---

### 4. 证据命名

```
evidence/
  S0/baseline.json
  S0/network.log
  S0/extensions.json
  S1/doctor-<date>.log
  S1/wizard-declined-<date>.log
  S2/interview-<date>.md
  S3/validate-<date>.log
  S4/single-export-<date>.log
  S4/all-export-<date>.log
  S4/download-dir-<date>.png
  S5/index-<date>.log
  S5/db-query-<date>.txt
  S6/fourway-<date>.log
  S7/validate-legal-<date>.log
  S8/agent-dialogue-<date>.md
```

规则：

- 日期用 `YYYYMMDD`；
- 同一步骤多个证据加序号；
- 大文件（zip/db）不进仓库，只留路径 + SHA256；
- 截图含账号名/头像要打码；
- 日志不含 token/cookie/手机号/身份证。

---

### 5. PASS 表模板（总控汇总用）

| WS | 步骤 | 结果 | 证据级别 | 真实/mock | 备注 |
|---|---|---|---|---|---|
| WS1 | S1 | PASS | L2 | real | |
| WS3 | S4 | BLOCKED | L1 | mock | 等本地 Edge |
| ... | | | | | |

规则：

- 只有 L1 的 PASS 标 `smoke-only`；
- BLOCKED 写缺什么；
- PASS-WITH-FRICTION 写用户是否接受；
- 任何 P0 未解决，整行不能写 PASS。

---

### 6. 发布门禁表模板

| 检查 | 结果 | 证据 | 谁确认 |
|---|---|---|---|
| Windows 11 干净安装 | | | |
| Ubuntu 24.04 干净安装 | | | |
| DOCTOR_OK | | | |
| SMOKE_OK | | | |
| VALIDATE_OK | | | |
| 0 P0 | | | |
| P1 修复/接受 | | | |
| 校验和 | | | |
| 回滚演练 | | | |
| CLOSED issue 在分支 | | | |
| 用户批准 | | | |
```

---
