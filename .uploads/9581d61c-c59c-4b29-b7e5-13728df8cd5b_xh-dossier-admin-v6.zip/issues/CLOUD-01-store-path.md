# CLOUD-01 · 官方商店路径在云端 Chromium 不可用，Edge Addons 的“获取”按钮也被禁用

- 步骤：S4.1 扩展安装
- 环境：云端 Linux / Chromium 146.0.7680.31 / 干净 profile / 代理可用（GitHub 可达）
- 证据级别：L1（截图 + 页面文本）
- 影响：P1（环境限制，不是产品 bug；但会影响“普通用户第一次安装”的结论）

## 现象

1. 打开 Chrome Web Store 的 ScriptCat 页面：
   - `https://chromewebstore.google.com/detail/hompjdfbfoggjbeebconmlijpelpfapo`
   - 页面报“检查代理服务器和防火墙”，无法加载。
2. 打开 Edge Addons 的 ScriptCat 页面：
   - `https://microsoftedge.microsoft.com/addons/detail/liilgpjgabokdklappibcjfablkpcekh`
   - 页面能加载，但当前浏览器是 Chromium（Chrome 内核），页面上的“获取”按钮是 disabled；不能把“页面能打开”写成“能安装”。
3. 官方 GitHub release 页面可下载：
   - `https://github.com/scriptscat/scriptcat/releases/tag/v1.5.2`
   - `scriptcat-v1.5.2-chrome.zip` 下载成功，5,323,521 bytes。

## 期望

- 普通用户从官方商店能装；
- 如果商店不可达，安装指南要明确给官方 release fallback，并说明“这不是商店路径通过”。

## 实际

- 商店路径在云端不可用；
- Edge Addons 在 Chromium 中不可安装；
- 只有官方 GitHub release 可用。

## 证据

- `evidence/extensions-page.png`：Chrome 扩展页；
- `evidence/proxy-test.png`：代理/商店报错；
- `evidence/scriptcat-details.png`：Edge Addons 页面，按钮 disabled；
- `evidence/ext/scriptcat-v1.5.2-chrome.zip`：5,323,521 bytes。

## 验收

- 安装指南有两条路径：官方商店 / 官方 release；
- 每条路径都有 URL、版本、SHA256、成功/失败截图；
- 不把“GitHub release 能装”写成“商店路径已通过”；
- 本地真实 Edge 环境要再测一次商店路径（Track B）。

## 不做

- 不修商店/代理；
- 不 curl 拉 CRX 冒充用户路径；
- 不把云端 browser-use 当普通用户本机。
