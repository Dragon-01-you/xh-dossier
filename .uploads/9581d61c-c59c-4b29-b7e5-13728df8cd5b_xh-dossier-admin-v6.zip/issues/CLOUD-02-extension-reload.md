# CLOUD-02 · 安装 AfterChat 后不重载扩展，白色导出按钮不会注入

- 步骤：S4.2 按钮出现 / S4.9 扩展重载
- 环境：云端 Linux / Chromium 146.0.7680.31 / 干净 profile / ScriptCat 1.5.2 / AfterChat 1.25.0
- 证据级别：L2（同一环境前后对比 + 截图 + DOM 断言）
- 影响：P0（普通用户会以为“装了但没用”）

## 现象

安装 AfterChat 后，直接打开 mock DeepSeek 会话页：

- `document.getElementById('m365-export-container')` = `false`
- 截图只有白页 “Hello / Hi there”，没有白色按钮。

打开 `chrome://extensions`，执行：

```js
chrome.developerPrivate.reload('adoaajilakgjdhgfagodfoaoldhffaid', {failQuietly:true})
```

再打开同一个页面：

- `m365-export-container` = `true`
- 按钮 rect：`{x:1224, y:844, width:36, height:36}`
- 点击后真实下载 `Mock Conversation.md` 374 bytes。

## 期望

安装指南应写：

1. 装 ScriptCat；
2. 开 `Allow User Scripts`；
3. 装 AfterChat；
4. **重载一次扩展**（不是只 Ctrl+F5 页面）；
5. 再打开目标页；
6. 确认按钮出现。

## 实际

当前文档/流程只写“强刷新页面”，不够。只 Ctrl+F5 时按钮不出现。

## 证据

- `evidence/mock-deepseek-button.png`：未重载，白页无按钮；
- `evidence/mock-after-reload.png`：重载后有按钮；
- `evidence/mock-diag.log`：`CONTAINER True`；
- `evidence/mock-export-evidence2.log`：`container True` + `DOWNLOAD Mock Conversation.md 374`；
- `evidence/afterchat-button.png`：按钮元素截图。

## 验收

- 安装向导/手册出现“重载扩展”步骤；
- 有一个检查：`#m365-export-container` 不存在时，提示“先重载扩展，再刷新页面”；
- 回归 fixture：`afterchat-no-reload` 断言按钮不存在；`afterchat-reload` 断言按钮存在；
- 本地真实 Edge 再复现一次（Track B）。

## 不做

- 不把“重载扩展”写成“重启浏览器”；
- 不假设所有用户都懂开发者模式；
- 不把按钮出现当导出成功。
