# CLOUD-03 · DeepSeek 分享链接 `/share/...` 不注入按钮，AfterChat adapter 只认 `/a/chat/s/...`

- 步骤：S4.11 分享页支持
- 环境：云端 Linux / Chromium 146.0.7680.31 / ScriptCat 1.5.2 / AfterChat 1.25.0 / 未登录
- 证据级别：L1（真实页面 + DOM 断言 + 截图）
- 影响：P1（常见用户路径；但 `/a/chat/s/` 是主路径）

## 现象

打开真实 DeepSeek 分享页：

`https://chat.deepseek.com/share/horj9tlug5klc6q8oj`

- 页面正常显示 “Shared Conversation”；
- `document.getElementById('m365-export-container')` = `false`；
- 无白色导出按钮。

AfterChat 源码中 DeepSeek adapter 只匹配 `/a/chat/s/<id>`，不匹配 `/share/<id>`。

## 期望

二选一：

1. R0 明确写 known-limit：分享页不支持，用户要打开自己的会话页 `/a/chat/s/<id>`；
2. 后续 issue 支持 `/share/`，并加 fixture。

## 实际

分享页完全没有注入，用户会以为扩展坏了。

## 证据

- `evidence/deepseek-share-afterchat.png`：分享页无按钮；
- `evidence/share-after-reload.log`：`container False`；
- `evidence/share-after-reload.png`：重载后仍无按钮；
- AfterChat 源码：`afterchat-src/afterchat.user.js`，DeepSeek adapter 约 2822–2925 行。

## 验收

- `known-limits.md` 写“分享页 `/share/` 暂不支持，请用会话页”；
- 安装向导/FAQ 有这一条；
- 如果做支持，加 `share-url` fixture，断言按钮出现 + 导出 >0 字节；
- 不把 `/share/` 失败写成“平台不支持导出”。

## 不做

- 不伪造登录态去测分享页；
- 不把分享页当主路径。
