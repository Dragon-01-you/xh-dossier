# CLOUD-04 · 导出 metadata 的 Model 出现重复前缀 `deepseek-deepseek-v4`

- 步骤：S4.10 导出 fidelity
- 环境：云端 Linux / Chromium 146.0.7680.31 / AfterChat 1.25.0 / mock DeepSeek
- 证据级别：L2（真实导出文件内容）
- 影响：P1（数据保真；不影响文件落盘，但会让档案里的模型名错）

## 现象

导出的 `Mock Conversation.md` 开头：

```md
## Metadata

- **Model:** `deepseek-deepseek-v4`
- **Time:** 2025-10-09 16:53:20 +08:00
- **URL:** https://chat.deepseek.com/a/chat/s/test-id
```

mock API 返回的 `chat_session.model_type` 是 `deepseek-v4`；AfterChat adapter 又拼了一次 `'deepseek-' + model_type`，得到 `deepseek-deepseek-v4`。

## 期望

- `Model: deepseek-v4`；
- 如果平台返回的已经是完整名，不再加前缀；
- 导出 fixture 断言 model 字段不重复。

## 实际

重复前缀，真实导出也会出现。

## 证据

- `evidence/Mock Conversation.md`：374 bytes，Model 行；
- `evidence/mock-export-evidence2.log`：导出日志 + 文件内容前 1500 字符；
- AfterChat 源码：`afterchat-src/afterchat.user.js` 约 2948 行，`'deepseek-' + model_type`。

## 验收

- 加 fixture：mock `model_type=deepseek-v4`，断言导出 `Model` 为 `deepseek-v4`；
- 加 fixture：mock `model_type=deepseek-reasoner`，断言不重复；
- 真实导出抽 3 条，人工核对 model 字段；
- 修复方式：优先给 AfterChat 上游提 issue；本地包装层做兼容；不阻塞 R0 落盘。

## 不做

- 不为了 model 字段重写整个导出器；
- 不把 mock 的 model 名当真实平台唯一值。
