# CLOUD-05 · `00_export_wizard.py --download-release` 在 GitHub API 403 时输出原始 traceback

- 步骤：S1.6 / S1 安装错误路径
- 环境：云端 Linux / Python 3.12.11 / 无 GitHub token / GitHub API rate limit
- 证据级别：L1（真实命令输出 + exit code）
- 影响：P1（普通用户看不懂；但不影响主流程）

## 现象

命令：

```bash
python3 00_export_wizard.py --download-release --yes
```

GitHub API 返回 403 rate limit，脚本输出原始 traceback：

```text
urllib.error.HTTPError: HTTP Error 403: rate limit exceeded
```

exit code 1。

## 期望

- 输出人话：`RELEASE_FETCH_FAILED: GitHub API 限流/无 token，请稍后重试或手动下载 release`；
- exit code 2（环境/网络错误）；
- 不输出完整 traceback；
- 日志保留技术细节到 `logs/`，屏幕只显示可操作信息。

## 实际

原始 traceback，用户不知道下一步。

## 证据

- `evidence/wizard-download-release.log`：完整 traceback；
- `evidence/wizard-declined.log`：declined exit 1 + `WIZARD_DECLINED`（这个是对的）；
- `evidence/wizard-dryrun.log`：dry-run exit 0。

## 验收

- fixture `release-403`：mock HTTP 403，断言 stdout 含 `RELEASE_FETCH_FAILED`，不含 `Traceback`，exit 2；
- fixture `release-timeout`：mock timeout，同上；
- fixture `release-ok`：mock 200 + zip，exit 0，文件 >0；
- 手册写“GitHub 限流时手动下载 release”。

## 不做

- 不把 403 当“用户没装好”；
- 不要求用户配 GitHub token 才能用主流程。
