# CLOUD-06 · 2 条 mock 记录也输出 `FOUR_WAY_OK`，容易被当生产 PASS

- 步骤：S6.5 样本量 / 生产 PASS
- 环境：云端 Linux / 2 条 mock 导出 / `02_four_way_match.py`
- 证据级别：L1–L2（真实命令 + 报告）
- 影响：P1（验收口径风险，不是代码崩溃）

## 现象

用 2 条 mock 记录跑 `02_four_way_match.py`：

```text
FOUR_WAY_OK records=2 clusters=1 out=.../backfill_candidates.md
```

报告有 Way 1 / Way 3 / Way 2&4 分节，但：

- Way 1 四个关键词命中 0；
- Way 3 只有 1 个长尾簇；
- Way 2&4 三个模式跨越 0 个簇、通过 0 条；
- 没有任何候选。

这个 `FOUR_WAY_OK` 只证明“脚本能跑完”，不能证明“四路匹配有效”。

## 期望

- 样本量不足时输出警告：`FOUR_WAY_LOW_SAMPLE`，并明确“仅 smoke，不可生产 PASS”；
- 生产 PASS 需 >=100 条真实记录，且四路各有非空结果或明确“无命中”原因；
- 报告头部写样本量 + 证据级别；
- CI 里 2 条 mock 只断言“能跑完 + 不崩溃”，不叫生产 PASS。

## 实际

`FOUR_WAY_OK` 没有区分 smoke / production。

## 证据

- `evidence/pipeline-fourway.log`：`FOUR_WAY_OK records=2 clusters=1`；
- `pipeline/work/backfill_candidates.md`：四路分节，但候选为空；
- `pipeline/work/unified_index.db`：2 条记录，role user/assistant，日期 2025-10-09。

## 验收

- 加 `FOUR_WAY_LOW_SAMPLE` 警告（records < 100）；
- 加 `--production` 模式：样本不足直接非零；
- fixture `mock-2-records`：断言有警告；
- fixture `real-100-records`：断言无警告 + 四路有结果/明确无命中；
- 成功标准里写清“2 条 mock 不算生产 PASS”。

## 不做

- 不为了通过而伪造 100 条数据；
- 不把空候选当“匹配算法有效”。
